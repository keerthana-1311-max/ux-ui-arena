import React, { useState, useEffect, useCallback, useSyncExternalStore } from 'react';
import { realtimeSync, initSupabaseSync } from './lib/realtimeSync';
import { supabase, isSupabaseConfigured } from './lib/supabase';
import BackgroundEffects from './components/BackgroundEffects';
import FloatingReactions from './components/FloatingReactions';
import JoinQuizModal from './components/JoinQuizModal';
import ParticipantView from './components/ParticipantView';
import CoordinatorLogin from './components/CoordinatorLogin';
import CoordinatorDashboard from './components/CoordinatorDashboard';

const useArena = () => useSyncExternalStore(realtimeSync.subscribe, realtimeSync.getState);

const hasLocalCoordAuth = () => {
  try {
    return !!sessionStorage.getItem('sparkle_coordinator_auth');
  } catch (e) {
    return false;
  }
};

export default function App() {
  return (
    <div className="min-h-screen bg-[#080914] text-slate-100 font-sans selection:bg-purple-500 selection:text-white">
      <BackgroundEffects />
      <FloatingReactions />
      <LiveArena />
    </div>
  );
}

function LiveArena() {
  const { session, participants, answers, results } = useArena();
  const [isCoord, setIsCoord] = useState(hasLocalCoordAuth());
  const [showLogin, setShowLogin] = useState(false);
  const [pid, setPid] = useState(() => {
    try {
      return localStorage.getItem('sparkle_pid') || sessionStorage.getItem('sparkle_pid');
    } catch (e) {
      return null;
    }
  });

  // 1. Initialize Supabase Realtime synchronization on mount
  useEffect(() => {
    initSupabaseSync();
  }, []);

  // 2. Check and listen to Supabase Coordinator Authentication
  useEffect(() => {
    if (isSupabaseConfigured() && supabase) {
      supabase.auth.getSession().then(({ data }) => {
        if (data?.session?.user) {
          setIsCoord(true);
        }
      });

      const { data: { subscription } } = supabase.auth.onAuthStateChange((event, authSession) => {
        if (authSession?.user) {
          setIsCoord(true);
        } else if (event === 'SIGNED_OUT') {
          setIsCoord(false);
        }
      });

      return () => subscription.unsubscribe();
    }
  }, []);

  // 3. Automatic Cross-Device Internet Relay (Zero-Config mode when Supabase env keys are absent)
  useEffect(() => {
    if (!isSupabaseConfigured()) {
      if (isCoord) {
        realtimeSync.enableHostMode(session?.pin || 'UX2026');
      } else {
        realtimeSync.enableParticipantMode(session?.pin || 'UX2026');
      }
    }
  }, [isCoord, session?.pin]);

  // 4. Find current participant object (or build from local storage)
  const me = participants.find((p) => p.id === pid) || (
    pid ? {
      id: pid,
      name: localStorage.getItem('sparkle_pname') || 'Contender',
      teamName: localStorage.getItem('sparkle_pteam') || 'Competitor',
      joinedAt: Date.now()
    } : null
  );

  // Participant actions
  const handleJoin = async ({ name, teamName, pin }) => {
    try {
      const newPid = await realtimeSync.joinQuiz({ name, teamName, pin });
      setPid(newPid);
    } catch (err) {
      console.error('Error joining quiz:', err);
      throw err;
    }
  };

  const handleSubmitAnswer = useCallback(async (participantId, qid, selectedOption) => {
    return realtimeSync.submitAnswer(participantId, qid, selectedOption);
  }, []);

  const handleLeave = () => {
    realtimeSync.leaveQuiz();
    setPid(null);
  };

  // Coordinator dashboard handlers
  const dashHandlers = {
    onStartQuiz: (duration) => realtimeSync.startQuiz(duration),
    onNextQuestion: () => realtimeSync.nextQuestion(),
    onPrevQuestion: () => realtimeSync.prevQuestion(),
    onLockQuestion: () => realtimeSync.lockQuestion(),
    onPauseQuiz: () => realtimeSync.pauseQuiz(),
    onResumeQuiz: () => realtimeSync.resumeQuiz(),
    onEndQuiz: () => realtimeSync.endQuiz(),
    onPreviewResults: () => realtimeSync.previewResults(),
    onPublishResults: () => realtimeSync.publishResults(),
    onResetSession: () => realtimeSync.resetSession(),
    onToggleRegistration: (open) => realtimeSync.toggleRegistration(open),
    onRemoveParticipant: (id) => realtimeSync.removeParticipant(id),
    onSetQuestionDuration: (d) => realtimeSync.setQuestionDuration(d),
    onLogout: async () => {
      try {
        sessionStorage.removeItem('sparkle_coordinator_auth');
        if (isSupabaseConfigured() && supabase) {
          await supabase.auth.signOut();
        }
      } catch (e) {}
      setIsCoord(false);
    },
  };

  // Render Coordinator Dashboard if authenticated
  if (isCoord) {
    return (
      <CoordinatorDashboard
        session={session}
        participants={participants}
        answers={answers}
        results={results}
        {...dashHandlers}
      />
    );
  }

  // Render Participant Experience
  return (
    <>
      {me ? (
        <ParticipantView
          session={session}
          participant={me}
          answers={answers}
          results={results}
          onSubmitAnswer={handleSubmitAnswer}
          onLeaveQuiz={handleLeave}
        />
      ) : (
        <JoinQuizModal
          session={session}
          onJoinSuccess={handleJoin}
          onOpenCoordinatorLogin={() => setShowLogin(true)}
        />
      )}

      {showLogin && (
        <CoordinatorLogin
          onLoginSuccess={() => {
            setIsCoord(true);
            setShowLogin(false);
          }}
          onCancel={() => setShowLogin(false)}
        />
      )}
    </>
  );
}
