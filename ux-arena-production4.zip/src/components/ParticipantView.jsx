import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Hourglass, 
  ShieldCheck, 
  User, 
  Users,
  Check,
  Pause,
  Smile,
  LogOut,
  Trophy
} from 'lucide-react';
import { PUBLIC_QUESTIONS } from '../data/questions';
import VisualQuestionRenderer from './VisualQuestionRenderer';
import ScoreboardView from './ScoreboardView';
import { sound } from '../utils/sound';
import { realtimeSync } from '../lib/realtimeSync';

export default function ParticipantView({
  session,
  participant,
  answers = {},
  results,
  onSubmitAnswer,
  onLeaveQuiz
}) {
  const duration = session?.questionDuration || 20;
  const [timeLeft, setTimeLeft] = useState(session?.timeRemaining ?? duration);
  const [selectedOption, setSelectedOption] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const timerIntervalRef = useRef(null);

  const currentQIndex = session?.currentQuestionIndex ?? -1;
  const currentQ = currentQIndex >= 0 && currentQIndex < PUBLIC_QUESTIONS.length ? PUBLIC_QUESTIONS[currentQIndex] : null;

  // Retrieve already submitted answer for this participant & question
  const existingSubmission = currentQ && participant ? answers[participant.id]?.[currentQ.id] : null;

  // Compute synchronized timer based on session.questionStartedAt and pause status
  useEffect(() => {
    if (!session || session.status !== 'in_progress' || !session.questionStartedAt || !currentQ) {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      return;
    }

    if (session.isPaused) {
      setTimeLeft(session.timeRemaining ?? 0);
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      return;
    }

    const calculateRemaining = () => {
      const now = Date.now();
      const elapsed = (now - session.questionStartedAt) / 1000;
      const qDuration = session.questionDuration || 20;
      const remaining = Math.max(0, Math.ceil(qDuration - elapsed));

      setTimeLeft(remaining);

      // Warning audio on final 3 seconds
      if (remaining <= 3 && remaining > 0) {
        sound.playWarning();
      }

      if (remaining <= 0) {
        if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      }
    };

    calculateRemaining();
    timerIntervalRef.current = setInterval(calculateRemaining, 250);

    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, [session?.questionStartedAt, session?.isPaused, session?.timeRemaining, session?.status, currentQIndex, session?.questionDuration]);

  // Synchronize local selected option with existing submission (freely changeable)
  useEffect(() => {
    if (existingSubmission && existingSubmission.selectedOption) {
      setSelectedOption(existingSubmission.selectedOption);
    } else {
      setSelectedOption(null);
    }
  }, [currentQIndex, existingSubmission]);

  // Handle option selection without answer locking (participants can change choice anytime before timer runs out)
  const handleSelectAndSubmit = async (optionId) => {
    if (timeLeft <= 0 || session?.isPaused || submitting) {
      return;
    }

    sound.playSelect();
    setSelectedOption(optionId);
    setSubmitting(true);

    if (currentQ && participant) {
      try {
        await onSubmitAnswer(participant.id, currentQ.id, optionId);
      } finally {
        setSubmitting(false);
      }
    }
  };

  const isWarning = timeLeft <= 3 && timeLeft > 0;
  const timerPercentage = Math.min(100, Math.max(0, (timeLeft / duration) * 100));

  // Quick reaction emojis
  const handleReact = (emoji) => {
    realtimeSync.sendReaction(emoji);
  };

  // If results are published or finalized, show the full final scoreboard to participants!
  if (session?.resultsPublished || session?.status === 'finalized') {
    return (
      <div className="relative z-10 max-w-5xl mx-auto px-4 py-6">
        <ScoreboardView
          results={results}
          session={session}
          isCoordinatorView={false}
          currentParticipantId={participant?.id}
        />
      </div>
    );
  }

  return (
    <div className="relative z-10 max-w-4xl mx-auto px-4 py-4 sm:py-6 flex flex-col justify-between min-h-[calc(100vh-80px)]">
      {/* Top Participant Header */}
      <div className="glass-panel p-4 rounded-2xl border-purple-500/20 mb-4 flex flex-wrap items-center justify-between gap-3 shadow-lg">
        {/* Branding & Arena Title */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 to-pink-600 flex items-center justify-center text-white shadow-md">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-sm sm:text-base tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400">
                SPARKLE '26
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-purple-950/70 border border-purple-500/30 text-purple-300">
                UX ARENA
              </span>
            </div>
            <span className="text-[11px] font-mono text-slate-400">
              UI/UX BATTLE • LIVE CONTESTANT
            </span>
          </div>
        </div>

        {/* Participant Identity & Leave Button */}
        <div className="flex items-center gap-2 text-right">
          <div className="bg-slate-900/90 border border-purple-500/30 px-3.5 py-1.5 rounded-xl">
            <div className="text-xs font-bold text-white flex items-center gap-1.5 justify-end">
              <User className="w-3.5 h-3.5 text-purple-400" />
              <span>{participant?.name || 'Participant'}</span>
            </div>
            <div className="text-[10px] font-mono text-pink-300 flex items-center gap-1 justify-end">
              <Users className="w-3 h-3 text-pink-400" />
              <span>Team: {participant?.teamName || 'Designers'}</span>
            </div>
          </div>

          <button
            onClick={onLeaveQuiz}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-red-500 text-slate-500 hover:text-red-400 transition cursor-pointer"
            title="Leave / Change Nickname"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* STATE 1: WAITING FOR START (LOBBY) */}
      {session?.status === 'registration' && (
        <div className="my-auto glass-panel p-8 sm:p-12 rounded-3xl border-2 border-purple-500/30 text-center shadow-glow-purple max-w-xl mx-auto">
          <div className="w-16 h-16 rounded-2xl bg-purple-500/10 border border-purple-500/30 mx-auto flex items-center justify-center text-purple-400 mb-4 animate-pulse">
            <Hourglass className="w-8 h-8 text-pink-400" />
          </div>

          <span className="text-xs font-mono font-bold text-purple-300 bg-purple-950/70 border border-purple-500/30 px-3 py-1 rounded-full uppercase">
            Connected to Arena Lobby
          </span>

          <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-3 font-display">
            Waiting for the Coordinator to Start
          </h2>

          <p className="text-sm text-slate-400 mt-2 leading-relaxed">
            You are checked in as <strong className="text-white">{participant?.name}</strong> (<span className="text-purple-300">{participant?.teamName}</span>).
            Questions are controlled exclusively by event organizers and will automatically appear simultaneously on this screen.
          </p>

          <div className="mt-6 p-4 bg-slate-950/80 border border-slate-800 rounded-xl text-xs font-mono text-slate-300 flex items-center justify-around">
            <div>
              <span className="text-slate-500 block">Total Questions</span>
              <span className="text-white font-bold text-base">10 Questions</span>
            </div>
            <div className="h-8 w-px bg-slate-800" />
            <div>
              <span className="text-slate-500 block">Time Per Question</span>
              <span className="text-cyan-400 font-bold text-base">{duration} Seconds</span>
            </div>
            <div className="h-8 w-px bg-slate-800" />
            <div>
              <span className="text-slate-500 block">Total Marks</span>
              <span className="text-pink-400 font-bold text-base">15 Marks</span>
            </div>
          </div>

          {/* Quick Cheer Emojis */}
          <div className="mt-6 pt-4 border-t border-purple-500/20">
            <span className="text-xs text-slate-400 font-mono block mb-2">Send cheer reactions:</span>
            <div className="flex justify-center gap-3">
              {['🔥', '✨', '⚡', '🚀', '💡', '🎉'].map((emoji) => (
                <button
                  key={emoji}
                  onClick={() => handleReact(emoji)}
                  className="text-2xl p-2 rounded-xl bg-slate-900 border border-purple-500/30 hover:scale-125 transition-transform cursor-pointer"
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* STATE 2: ACTIVE QUESTION RUNNER */}
      {session?.status === 'in_progress' && currentQ && (
        <div className="my-2 glass-panel p-5 sm:p-8 rounded-3xl border-purple-500/30 shadow-2xl relative overflow-hidden transition-all duration-300">
          {/* Top Bar: Section Badge + Synchronized Timer */}
          <div className="flex items-center justify-between gap-3 pb-3 mb-4 border-b border-purple-500/20">
            <div className="flex items-center gap-2">
              <span className={`text-xs font-mono font-bold px-3 py-1 rounded-xl border ${
                currentQ.section === 'A'
                  ? 'bg-purple-950/80 text-purple-300 border-purple-500/40'
                  : 'bg-pink-950/80 text-pink-300 border-pink-500/40'
              }`}>
                {currentQ.sectionTitle}
              </span>
              <span className="text-xs font-mono text-slate-400">
                Question {currentQIndex + 1} of {PUBLIC_QUESTIONS.length}
              </span>
            </div>

            {/* Synchronized Animated Timer Display */}
            <div className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl border transition-all duration-300 ${
              session?.isPaused
                ? 'bg-amber-950/80 border-amber-500 text-amber-300'
                : isWarning
                ? 'bg-red-950/80 border-red-500 animate-timer-warning text-red-300'
                : 'bg-slate-900/90 border-purple-500/40 text-white shadow-glow-purple'
            }`}>
              <div className="relative w-5 h-5 flex items-center justify-center">
                <svg className="w-5 h-5 -rotate-90" viewBox="0 0 36 36">
                  <path
                    className="text-slate-800"
                    strokeWidth="3.5"
                    stroke="currentColor"
                    fill="none"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                  <path
                    className={session?.isPaused ? "text-amber-400" : isWarning ? "text-red-500 transition-all duration-200" : "text-purple-400 transition-all duration-200"}
                    strokeDasharray={`${timerPercentage}, 100`}
                    strokeWidth="4"
                    strokeLinecap="round"
                    stroke="currentColor"
                    fill="none"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                </svg>
                {session?.isPaused ? (
                  <Pause className="w-2.5 h-2.5 absolute text-amber-400" />
                ) : (
                  <Clock className={`w-2.5 h-2.5 absolute ${isWarning ? 'text-red-400' : 'text-purple-400'}`} />
                )}
              </div>

              <span className={`font-mono font-bold text-base tracking-wider ${
                session?.isPaused ? 'text-amber-300' : isWarning ? 'text-red-400 animate-pulse' : 'text-white'
              }`}>
                {session?.isPaused ? 'PAUSED' : `${timeLeft}s`}
              </span>
            </div>
          </div>

          {/* Pause Notice */}
          {session?.isPaused && (
            <div className="mb-4 p-3 bg-amber-950/70 border border-amber-500/50 rounded-xl text-xs text-amber-200 font-mono flex items-center gap-2 animate-pulse">
              <Pause className="w-4 h-4 text-amber-400 shrink-0" />
              <span>Quiz temporarily paused by coordinator. Timer and answering are currently on hold.</span>
            </div>
          )}

          {/* Question Text */}
          <div className="mb-4">
            <h2 className="text-xl sm:text-2xl md:text-3xl font-extrabold text-white tracking-tight leading-snug">
              {currentQ.question}
            </h2>
          </div>

          {/* Visual Asset Display */}
          <div className="my-4 bg-slate-950/70 border border-slate-800 rounded-2xl p-2 sm:p-4 shadow-inner">
            <VisualQuestionRenderer question={currentQ} />
          </div>

          {/* Four Selectable Answer Choices (Freely Changeable until timer ends) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 mt-5">
            {currentQ.options.map((option) => {
              const isSelected = selectedOption === option.id;
              const isDisabled = timeLeft <= 0 || session?.isPaused;

              return (
                <button
                  key={option.id}
                  type="button"
                  disabled={isDisabled}
                  onClick={() => handleSelectAndSubmit(option.id)}
                  className={`text-left p-4 sm:p-5 rounded-2xl transition-all duration-200 flex items-center justify-between ${
                    isSelected
                      ? 'glass-card-active scale-[1.01] border-2 border-purple-400 shadow-glow-purple'
                      : isDisabled
                      ? 'bg-slate-900/40 border border-slate-800/80 opacity-60 cursor-not-allowed text-slate-400'
                      : 'glass-panel glass-panel-hover border-slate-800 text-slate-200 cursor-pointer active:scale-98'
                  }`}
                >
                  <div className="flex items-center gap-3.5">
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-mono font-bold text-sm shrink-0 ${
                      isSelected
                        ? 'bg-gradient-to-tr from-purple-500 to-pink-500 text-white shadow-glow-purple'
                        : 'bg-slate-800 text-slate-300 border border-slate-700'
                    }`}>
                      {option.id}
                    </div>
                    <span className="text-sm sm:text-base font-semibold leading-relaxed">
                      {option.text}
                    </span>
                  </div>

                  <div className={`w-6 h-6 rounded-full flex items-center justify-center border-2 shrink-0 ml-3 ${
                    isSelected
                      ? 'border-purple-400 bg-purple-500 text-white shadow-glow-purple'
                      : 'border-slate-700'
                  }`}>
                    {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Submission Status Banner */}
          <div className="mt-5 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
            {selectedOption ? (
              <div className="flex items-center gap-2 text-emerald-300 font-semibold bg-emerald-950/70 border border-emerald-500/40 px-3.5 py-1.5 rounded-xl">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>
                  Option {selectedOption} Selected • {timeLeft > 0 ? 'Tap any option to switch answer' : 'Recorded'}
                </span>
              </div>
            ) : timeLeft === 0 ? (
              <div className="flex items-center gap-2 text-amber-400 font-semibold bg-amber-950/60 border border-amber-500/30 px-3.5 py-1.5 rounded-xl">
                <AlertCircle className="w-4 h-4" />
                <span>Time Expired – Marked as Unanswered</span>
              </div>
            ) : session?.isPaused ? (
              <div className="flex items-center gap-2 text-amber-300">
                <Pause className="w-4 h-4 text-amber-400" />
                <span>Session paused — timer standing by...</span>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-purple-300">
                <Hourglass className="w-4 h-4 animate-spin text-pink-400" />
                <span>Select an answer before time expires! (Changeable anytime)</span>
              </div>
            )}

            {/* Quick Floating Emoji Reaction */}
            <div className="flex items-center gap-1.5 ml-auto">
              <span className="text-slate-500 text-[10px]">Cheer:</span>
              {['🔥', '✨', '⚡', '🎉'].map((e) => (
                <button
                  key={e}
                  type="button"
                  onClick={() => handleReact(e)}
                  className="text-base p-1 hover:scale-125 transition-transform cursor-pointer"
                >
                  {e}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* STATE 3: ROUND COMPLETED / AWAITING PUBLICATION */}
      {(session?.status === 'completed' || (session?.status === 'finalized' && !session?.resultsPublished)) && (
        <div className="my-auto glass-panel p-8 sm:p-12 rounded-3xl border-2 border-purple-500/30 text-center shadow-glow-purple max-w-xl mx-auto">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-purple-600 to-pink-600 mx-auto flex items-center justify-center text-white mb-4 shadow-lg">
            <CheckCircle2 className="w-9 h-9" />
          </div>

          <span className="text-xs font-mono font-bold text-pink-300 bg-pink-950/70 border border-pink-500/30 px-3.5 py-1 rounded-full uppercase">
            ROUND 1 BATTLE FINISHED
          </span>

          <h2 className="text-2xl sm:text-4xl font-extrabold text-white mt-3 font-display">
            Battle Completed!
          </h2>

          <p className="text-sm text-slate-300 mt-3 leading-relaxed">
            All 10 questions have concluded. Thank you for competing, <strong className="text-white">{participant?.name}</strong> (<span className="text-purple-300">{participant?.teamName}</span>)!
          </p>

          <div className="mt-6 p-4 bg-slate-950/80 border border-purple-500/20 rounded-2xl text-xs text-slate-400 leading-relaxed font-mono">
            📢 Official scores and ranks are being compiled by event organizers. The official live scoreboard will be released here automatically as soon as the coordinator publishes it.
          </div>
        </div>
      )}

      {/* Minimal Footer Info */}
      <div className="pt-2 flex items-center justify-between text-xs text-slate-500 font-mono">
        <span>SPARKLE '26 • UX ARENA</span>
        <span>Live Synchronized Session</span>
      </div>
    </div>
  );
}
