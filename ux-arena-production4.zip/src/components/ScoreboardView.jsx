import React, { useState, useEffect } from 'react';
import { 
  Trophy, 
  Award, 
  Download, 
  Users, 
  TrendingUp, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  Eye, 
  X, 
  Sparkles, 
  Maximize2, 
  Minimize2,
  FileSpreadsheet,
  Send,
  Tv,
  UserCheck
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { QUESTIONS } from '../data/questions';
import { computeResults, realtimeSync } from '../lib/realtimeSync';

export default function ScoreboardView({ 
  results, 
  session, 
  onResetSession, 
  isCoordinatorView = false,
  onPublishResults,
  publishing = false,
  currentParticipantId = null
}) {
  const [selectedParticipant, setSelectedParticipant] = useState(null);
  const [filterQuery, setFilterQuery] = useState('');
  const [isProjectorMode, setIsProjectorMode] = useState(false);

  // Trigger celebration confetti when results are displayed
  useEffect(() => {
    if (session?.resultsPublished || isCoordinatorView) {
      try {
        confetti({
          particleCount: 90,
          spread: 80,
          origin: { y: 0.6 }
        });
      } catch (e) {}
    }
  }, [session?.resultsPublished, isCoordinatorView]);

  // Ensure activeResults is never null or empty
  const activeResults = (results && results.scoreboard && results.scoreboard.length > 0)
    ? results
    : computeResults(realtimeSync.getState());

  const { scoreboard = [], metrics = {} } = activeResults;

  // Find current user result for prominent scorecard display
  const myResult = currentParticipantId
    ? scoreboard.find((p) => p.participantId === currentParticipantId || p.id === currentParticipantId)
    : null;

  // Filter scoreboard by name or team
  const filteredScoreboard = scoreboard.filter(
    (p) =>
      p.name.toLowerCase().includes(filterQuery.toLowerCase()) ||
      p.teamName.toLowerCase().includes(filterQuery.toLowerCase())
  );

  // CSV Export utility
  const handleExportCsv = () => {
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Rank,Participant Name,Team Name,Total Score (/15),Section A (/5),Section B (/10),Correct Count,Incorrect Count,Unanswered Count\n";

    scoreboard.forEach((p) => {
      const row = [
        p.rank,
        `"${p.name.replace(/"/g, '""')}"`,
        `"${p.teamName.replace(/"/g, '""')}"`,
        `${p.totalScore}/15`,
        `${p.sectionAScore}/5`,
        `${p.sectionBScore}/10`,
        p.correctCount,
        p.incorrectCount,
        p.unansweredCount
      ].join(",");
      csvContent += row + "\n";
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `SPARKLE_26_UX_ARENA_RESULTS_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const toggleProjectorMode = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsProjectorMode(true);
    } else {
      if (document.exitFullscreen) document.exitFullscreen().catch(() => {});
      setIsProjectorMode(false);
    }
  };

  const getRankBadge = (rank) => {
    if (rank === 1) {
      return (
        <span className="flex items-center justify-center w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-400 to-yellow-600 text-slate-950 font-bold shadow-lg shadow-amber-500/30">
          🥇
        </span>
      );
    }
    if (rank === 2) {
      return (
        <span className="flex items-center justify-center w-8 h-8 rounded-xl bg-gradient-to-tr from-slate-200 to-slate-400 text-slate-950 font-bold shadow-lg">
          🥈
        </span>
      );
    }
    if (rank === 3) {
      return (
        <span className="flex items-center justify-center w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-700 to-amber-900 text-white font-bold shadow-lg">
          🥉
        </span>
      );
    }
    return (
      <span className="flex items-center justify-center w-8 h-8 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 font-mono font-bold text-sm">
        #{rank}
      </span>
    );
  };

  return (
    <div className={`w-full space-y-6 animate-fadeIn ${isProjectorMode ? 'p-6 bg-[#080914]' : ''}`}>
      {/* Coordinator Preview Banner (if not published yet) */}
      {isCoordinatorView && !session?.resultsPublished && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-950/90 to-pink-950/90 border-2 border-pink-500/50 shadow-glow-pink flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-pink-500/20 flex items-center justify-center text-pink-400">
              <Eye className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-mono font-bold text-pink-300 uppercase tracking-wider block">
                COORDINATOR PRIVATE PREVIEW
              </span>
              <p className="text-sm font-semibold text-white">
                Scores are currently hidden from participants until published.
              </p>
            </div>
          </div>

          {onPublishResults && (
            <button
              onClick={onPublishResults}
              disabled={publishing}
              className="px-6 py-3 rounded-xl font-display font-bold text-sm uppercase tracking-wider text-white shadow-lg shadow-pink-900/50 hover:shadow-glow-pink transition flex items-center gap-2 cursor-pointer animate-pulse"
              style={{ background: 'linear-gradient(135deg, #ec4899 0%, #8b5cf6 100%)' }}
            >
              <Send className="w-4 h-4" />
              <span>{publishing ? 'Publishing...' : 'Publish Results Live to Participants'}</span>
            </button>
          )}
        </div>
      )}

      {/* PARTICIPANT'S PERSONAL HERO SCORECARD (Shown when contestant views scoreboard) */}
      {!isCoordinatorView && myResult && (
        <div className="glass-panel p-6 sm:p-8 rounded-3xl border-2 border-pink-500/50 shadow-glow-purple bg-gradient-to-r from-purple-950/80 via-pink-950/60 to-purple-950/80 animate-fadeIn">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-mono font-bold uppercase tracking-widest text-pink-300 bg-pink-950/80 px-3 py-0.5 rounded-full border border-pink-500/40">
                  YOUR OFFICIAL SCORECARD
                </span>
                <span className="text-xs font-mono text-cyan-300">SPARKLE '26</span>
              </div>
              <h2 className="text-2xl sm:text-4xl font-extrabold text-white font-display mt-1">
                {myResult.name}
              </h2>
              <p className="text-sm text-purple-300 font-mono mt-0.5">
                Team: <strong className="text-white">{myResult.teamName}</strong>
              </p>
            </div>

            {/* Score & Rank Highlights */}
            <div className="flex flex-wrap items-center gap-4 sm:gap-6 bg-slate-950/80 border border-purple-500/30 p-4 rounded-2xl">
              <div className="text-center px-2">
                <span className="text-[11px] font-mono text-slate-400 block uppercase">YOUR RANK</span>
                <div className="flex items-center justify-center gap-1.5 mt-1">
                  <span className="text-3xl font-extrabold text-amber-300 font-mono">#{myResult.rank}</span>
                  {myResult.rank <= 3 && <span className="text-2xl">{myResult.rank === 1 ? '🥇' : myResult.rank === 2 ? '🥈' : '🥉'}</span>}
                </div>
              </div>

              <div className="h-10 w-px bg-slate-800" />

              <div className="text-center px-2">
                <span className="text-[11px] font-mono text-slate-400 block uppercase">TOTAL SCORE</span>
                <span className="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-purple-300 font-mono block mt-1">
                  {myResult.totalScore} <span className="text-xs text-slate-400 font-normal">/ 15</span>
                </span>
              </div>

              <div className="h-10 w-px bg-slate-800" />

              <div className="text-center px-2">
                <span className="text-[11px] font-mono text-slate-400 block uppercase">ACCURACY</span>
                <div className="flex items-center gap-1.5 justify-center mt-1 text-sm font-mono font-bold">
                  <span className="text-emerald-400">{myResult.correctCount} Correct</span>
                  <span className="text-slate-600">•</span>
                  <span className="text-red-400">{myResult.incorrectCount} Wrong</span>
                </div>
              </div>
            </div>
          </div>

          {/* Section Score Breakdown */}
          <div className="grid grid-cols-2 gap-3 mt-4 pt-4 border-t border-purple-500/20 text-xs font-mono">
            <div className="p-3 bg-purple-950/40 rounded-xl border border-purple-500/30 flex items-center justify-between">
              <span className="text-slate-300">Section A (Design Decode):</span>
              <span className="text-purple-300 font-bold text-sm">{myResult.sectionAScore} / 5 Marks</span>
            </div>
            <div className="p-3 bg-pink-950/40 rounded-xl border border-pink-500/30 flex items-center justify-between">
              <span className="text-slate-300">Section B (Visual UI/UX):</span>
              <span className="text-pink-300 font-bold text-sm">{myResult.sectionBScore} / 10 Marks</span>
            </div>
          </div>
        </div>
      )}

      {/* Top Header Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 glass-panel p-6 rounded-3xl border-purple-500/30">
        <div>
          <div className="flex items-center gap-2">
            <Trophy className="w-6 h-6 text-amber-400" />
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-display tracking-tight">
              Official Battle Scoreboard
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-purple-300 font-mono mt-1">
            SPARKLE '26 – UX ARENA: UI/UX BATTLE (ROUND 1) • FINAL RESULTS
          </p>
        </div>

        {/* Projector Mode & CSV Export Buttons */}
        <div className="flex items-center gap-3">
          <button
            onClick={toggleProjectorMode}
            className="px-4 py-2.5 rounded-xl bg-slate-900 border border-purple-500/40 hover:border-purple-300 text-purple-200 font-bold text-xs sm:text-sm flex items-center gap-2 transition cursor-pointer"
            title="Toggle Auditorium Projector Fullscreen Mode"
          >
            <Tv className="w-4 h-4" />
            <span>{isProjectorMode ? 'Exit Projector' : 'Projector Mode'}</span>
          </button>

          <button
            onClick={handleExportCsv}
            className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm flex items-center gap-2 transition shadow-lg shadow-emerald-900/40 cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Arena Overview Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="glass-panel p-5 rounded-2xl border-purple-500/20 flex items-center justify-between">
          <div>
            <span className="text-xs font-mono text-slate-400 uppercase">Total Contenders</span>
            <span className="text-3xl font-extrabold text-white font-mono block mt-1">
              {metrics?.totalParticipants || scoreboard.length || 0}
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-purple-500/10 flex items-center justify-center text-purple-400">
            <Users className="w-6 h-6" />
          </div>
        </div>

        <div className="glass-panel p-5 rounded-2xl border-pink-500/20 flex items-center justify-between">
          <div>
            <span className="text-xs font-mono text-slate-400 uppercase">Top Arena Score</span>
            <span className="text-3xl font-extrabold text-pink-400 font-mono block mt-1">
              {metrics?.highestScore ?? (scoreboard[0]?.totalScore || 0)} <span className="text-sm text-slate-500 font-normal">/ 15</span>
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-pink-500/10 flex items-center justify-center text-pink-400">
            <Trophy className="w-6 h-6" />
          </div>
        </div>

        <div className="glass-panel p-5 rounded-2xl border-cyan-500/20 flex items-center justify-between">
          <div>
            <span className="text-xs font-mono text-slate-400 uppercase">Average Score</span>
            <span className="text-3xl font-extrabold text-cyan-400 font-mono block mt-1">
              {metrics?.averageScore ?? (scoreboard.length ? Math.round((scoreboard.reduce((s, r) => s + r.totalScore, 0) / scoreboard.length) * 10) / 10 : 0)} <span className="text-sm text-slate-500 font-normal">/ 15</span>
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-cyan-500/10 flex items-center justify-center text-cyan-400">
            <TrendingUp className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Podium Top 3 Highlight Showcase */}
      {scoreboard.length >= 1 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 my-6">
          {/* Rank 2 */}
          {scoreboard[1] && (
            <div className="glass-panel p-5 rounded-2xl border-slate-400/40 text-center flex flex-col justify-between order-2 md:order-1">
              <div>
                <span className="text-4xl">🥈</span>
                <span className="text-xs font-mono font-bold text-slate-300 block uppercase mt-1">Rank 2 • Silver</span>
                <h3 className="text-xl font-bold text-white mt-1">{scoreboard[1].name}</h3>
                <p className="text-xs text-purple-300 font-mono">{scoreboard[1].teamName}</p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-800">
                <span className="text-2xl font-extrabold text-slate-200 font-mono">
                  {scoreboard[1].totalScore} <span className="text-xs text-slate-500">/ 15 Marks</span>
                </span>
                <div className="flex justify-center gap-3 text-[11px] font-mono text-slate-400 mt-1">
                  <span>Sec A: {scoreboard[1].sectionAScore}/5</span>
                  <span>•</span>
                  <span>Sec B: {scoreboard[1].sectionBScore}/10</span>
                </div>
              </div>
            </div>
          )}

          {/* Rank 1 - Champion */}
          {scoreboard[0] && (
            <div className="glass-panel p-6 rounded-2xl border-2 border-amber-400/60 shadow-glow-purple text-center flex flex-col justify-between order-1 md:order-2 bg-gradient-to-b from-amber-500/15 to-transparent">
              <div>
                <span className="text-5xl">👑 🥇</span>
                <span className="text-xs font-mono font-extrabold text-amber-300 block uppercase mt-2">Rank 1 • Champion</span>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">{scoreboard[0].name}</h3>
                <p className="text-sm text-amber-200 font-mono">{scoreboard[0].teamName}</p>
              </div>
              <div className="mt-4 pt-3 border-t border-amber-500/30">
                <span className="text-3xl font-extrabold text-amber-300 font-mono">
                  {scoreboard[0].totalScore} <span className="text-sm text-slate-400 font-normal">/ 15 Marks</span>
                </span>
                <div className="flex justify-center gap-3 text-xs font-mono text-slate-400 mt-1">
                  <span>Sec A: {scoreboard[0].sectionAScore}/5</span>
                  <span>•</span>
                  <span>Sec B: {scoreboard[0].sectionBScore}/10</span>
                </div>
              </div>
            </div>
          )}

          {/* Rank 3 */}
          {scoreboard[2] && (
            <div className="glass-panel p-5 rounded-2xl border-amber-800/40 text-center flex flex-col justify-between order-3">
              <div>
                <span className="text-4xl">🥉</span>
                <span className="text-xs font-mono font-bold text-amber-600 block uppercase mt-1">Rank 3 • Bronze</span>
                <h3 className="text-xl font-bold text-white mt-1">{scoreboard[2].name}</h3>
                <p className="text-xs text-purple-300 font-mono">{scoreboard[2].teamName}</p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-800">
                <span className="text-2xl font-extrabold text-amber-500 font-mono">
                  {scoreboard[2].totalScore} <span className="text-xs text-slate-500">/ 15 Marks</span>
                </span>
                <div className="flex justify-center gap-3 text-[11px] font-mono text-slate-400 mt-1">
                  <span>Sec A: {scoreboard[2].sectionAScore}/5</span>
                  <span>•</span>
                  <span>Sec B: {scoreboard[2].sectionBScore}/10</span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Search & Filter */}
      <div className="flex items-center justify-between gap-3">
        <input
          type="text"
          value={filterQuery}
          onChange={(e) => setFilterQuery(e.target.value)}
          placeholder="Filter by participant or team name..."
          className="w-full max-w-sm bg-slate-900/90 border border-purple-500/30 rounded-xl px-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-400"
        />
        <span className="text-xs font-mono text-slate-400">
          Showing {filteredScoreboard.length} of {scoreboard.length} contenders
        </span>
      </div>

      {/* Main Leaderboard Table */}
      <div className="glass-panel rounded-2xl border-purple-500/20 overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs sm:text-sm">
            <thead>
              <tr className="bg-slate-950/80 border-b border-purple-500/20 text-slate-400 font-mono uppercase text-[11px]">
                <th className="py-3.5 px-4 text-center">Rank</th>
                <th className="py-3.5 px-4">Participant Name</th>
                <th className="py-3.5 px-4">Team Name</th>
                <th className="py-3.5 px-4 text-center">Total Score</th>
                <th className="py-3.5 px-4 text-center hidden md:table-cell">Sec A (5M)</th>
                <th className="py-3.5 px-4 text-center hidden md:table-cell">Sec B (10M)</th>
                <th className="py-3.5 px-4 text-center hidden sm:table-cell">Accuracy</th>
                {isCoordinatorView && <th className="py-3.5 px-4 text-right">Answer Sheet</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredScoreboard.map((p, idx) => {
                const isMe = currentParticipantId && (p.participantId === currentParticipantId || p.id === currentParticipantId);

                return (
                  <tr 
                    key={p.participantId || idx}
                    className={`hover:bg-purple-950/20 transition ${
                      isMe ? 'bg-purple-900/40 border-l-4 border-l-pink-500 font-bold' : p.rank <= 3 ? 'bg-purple-950/10' : ''
                    }`}
                  >
                    <td className="py-3 px-4 text-center font-mono">
                      <div className="flex justify-center">{getRankBadge(p.rank)}</div>
                    </td>
                    <td className="py-3 px-4 font-semibold text-white">
                      <div className="flex items-center gap-1.5">
                        <span>{p.name}</span>
                        {isMe && (
                          <span className="text-[10px] font-mono bg-pink-500 text-white px-2 py-0.5 rounded-full">
                            YOU
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-purple-300 font-mono text-xs">
                      {p.teamName}
                    </td>
                    <td className="py-3 px-4 text-center font-mono font-bold text-base text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-purple-300">
                      {p.totalScore} <span className="text-xs text-slate-500 font-normal">/ 15</span>
                    </td>
                    <td className="py-3 px-4 text-center font-mono text-slate-300 hidden md:table-cell">
                      {p.sectionAScore}/5
                    </td>
                    <td className="py-3 px-4 text-center font-mono text-slate-300 hidden md:table-cell">
                      {p.sectionBScore}/10
                    </td>
                    <td className="py-3 px-4 text-center font-mono text-xs hidden sm:table-cell">
                      <span className="text-emerald-400">{p.correctCount}✓</span>
                      <span className="text-slate-500 mx-1">/</span>
                      <span className="text-red-400">{p.incorrectCount}✗</span>
                      {p.unansweredCount > 0 && (
                        <span className="text-slate-500 ml-1">({p.unansweredCount} -)</span>
                      )}
                    </td>
                    {isCoordinatorView && (
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => setSelectedParticipant(p)}
                          className="px-3 py-1.5 rounded-lg bg-slate-900 border border-purple-500/40 hover:border-purple-300 text-purple-300 hover:text-white text-xs font-mono transition cursor-pointer"
                        >
                          Audit Answers
                        </button>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Individual Answer Audit Modal (Coordinator Only) */}
      {isCoordinatorView && selectedParticipant && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-lg animate-fadeIn overflow-y-auto">
          <div className="glass-panel w-full max-w-3xl max-h-[90vh] rounded-3xl border-2 border-purple-500/40 shadow-glow-purple flex flex-col overflow-hidden my-auto">
            {/* Header */}
            <div className="p-4 sm:p-6 border-b border-purple-500/20 bg-slate-950/80 flex items-center justify-between">
              <div>
                <h3 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
                  <span>Answer Audit: {selectedParticipant.name}</span>
                  <span className="text-xs font-mono bg-purple-900/60 text-purple-300 px-2 py-0.5 rounded-full">
                    Team: {selectedParticipant.teamName}
                  </span>
                </h3>
                <p className="text-xs font-mono text-slate-400 mt-0.5">
                  Score: <strong className="text-white text-sm">{selectedParticipant.totalScore}/15</strong> (Rank #{selectedParticipant.rank})
                </p>
              </div>

              <button
                onClick={() => setSelectedParticipant(null)}
                className="p-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Questions Answer Review */}
            <div className="p-4 sm:p-6 overflow-y-auto space-y-3">
              {QUESTIONS.map((q) => {
                const answerRecord = selectedParticipant.answers?.[q.id];
                const selectedOpt = answerRecord?.selectedOption;
                const isCorrect = selectedOpt === q.correctAnswer;
                const isUnanswered = !selectedOpt;

                return (
                  <div
                    key={q.id}
                    className={`p-3.5 rounded-xl border text-xs sm:text-sm ${
                      isUnanswered
                        ? 'bg-amber-950/20 border-amber-500/30'
                        : isCorrect
                        ? 'bg-emerald-950/20 border-emerald-500/30'
                        : 'bg-red-950/20 border-red-500/30'
                    }`}
                  >
                    <div className="flex items-center justify-between font-mono text-xs mb-1">
                      <span className="text-slate-400 font-bold">Q{q.id} • {q.sectionTitle}</span>
                      <span className={`px-2 py-0.5 rounded font-bold ${
                        isCorrect ? 'bg-emerald-900/60 text-emerald-300' : 'bg-red-900/60 text-red-300'
                      }`}>
                        {isCorrect ? `+${q.marks} Marks` : '0 Marks'}
                      </span>
                    </div>

                    <p className="text-white font-medium my-1">{q.question}</p>

                    <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-slate-800 text-xs font-mono">
                      <div>
                        <span className="text-slate-500 block">Participant Answer:</span>
                        <span className={isCorrect ? 'text-emerald-300 font-bold' : 'text-red-300 font-bold'}>
                          {selectedOpt ? `Option ${selectedOpt}` : 'Not Answered / Timed Out'}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 block">Correct Answer:</span>
                        <span className="text-purple-300 font-bold">
                          Option {q.correctAnswer}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="p-4 border-t border-purple-500/20 bg-slate-950/80 flex justify-end">
              <button
                onClick={() => setSelectedParticipant(null)}
                className="px-5 py-2 rounded-xl bg-purple-600 text-white font-bold text-xs"
              >
                Close Audit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
