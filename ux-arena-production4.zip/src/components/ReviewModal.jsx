import React, { useState } from 'react';
import { 
  X, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  Award, 
  BookOpen, 
  Sparkles, 
  ChevronDown, 
  ChevronUp,
  Filter
} from 'lucide-react';

export default function ReviewModal({ questions, answers, isOpen, onClose }) {
  const [filter, setFilter] = useState('all'); // 'all', 'correct', 'incorrect'
  const [expandedId, setExpandedId] = useState(null);

  if (!isOpen) return null;

  const toggleExpand = (id) => {
    setExpandedId(expandedId === id ? null : id);
  };

  const filteredQuestions = questions.filter((q) => {
    const isCorrect = answers[q.id] === q.correctAnswer;
    if (filter === 'correct') return isCorrect;
    if (filter === 'incorrect') return !isCorrect;
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-lg animate-fadeIn overflow-y-auto">
      <div className="glass-panel w-full max-w-4xl max-h-[90vh] rounded-3xl border-2 border-purple-500/40 shadow-glow-purple flex flex-col overflow-hidden my-auto">
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-purple-500/20 bg-slate-950/80 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-300">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
                <span>Battle Performance & Answer Audit</span>
                <span className="text-xs font-mono bg-purple-900/60 text-purple-300 px-2.5 py-0.5 rounded-full border border-purple-500/30">
                  Round 1
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Detailed design rationales and usability heuristics breakdown
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-purple-400 text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Bar */}
        <div className="px-6 py-3 bg-slate-900/60 border-b border-slate-800 flex items-center justify-between flex-wrap gap-2 text-xs font-mono">
          <div className="flex items-center gap-2 text-slate-400">
            <Filter className="w-3.5 h-3.5" />
            <span>Filter by:</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1 rounded-lg transition ${
                filter === 'all'
                  ? 'bg-purple-600 text-white font-bold'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              All (10)
            </button>
            <button
              onClick={() => setFilter('correct')}
              className={`px-3 py-1 rounded-lg transition ${
                filter === 'correct'
                  ? 'bg-emerald-600 text-white font-bold'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              Correct
            </button>
            <button
              onClick={() => setFilter('incorrect')}
              className={`px-3 py-1 rounded-lg transition ${
                filter === 'incorrect'
                  ? 'bg-red-600 text-white font-bold'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              Incorrect / Missed
            </button>
          </div>
        </div>

        {/* Questions List */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4">
          {filteredQuestions.map((q) => {
            const userAnswer = answers[q.id];
            const isCorrect = userAnswer === q.correctAnswer;
            const userOption = q.options.find((opt) => opt.id === userAnswer);
            const correctOption = q.options.find((opt) => opt.id === q.correctAnswer);
            const isExpanded = expandedId === q.id || filter !== 'all';

            return (
              <div
                key={q.id}
                className={`p-4 sm:p-5 rounded-2xl border transition-all duration-200 ${
                  isCorrect
                    ? 'bg-emerald-950/20 border-emerald-500/30 hover:border-emerald-500/50'
                    : 'bg-red-950/20 border-red-500/30 hover:border-red-500/50'
                }`}
              >
                {/* Question Header */}
                <div 
                  className="flex items-start justify-between gap-3 cursor-pointer"
                  onClick={() => toggleExpand(q.id)}
                >
                  <div className="flex items-start gap-3">
                    <div className="mt-0.5">
                      {isCorrect ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                      ) : (
                        <XCircle className="w-5 h-5 text-red-400" />
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-mono font-bold text-slate-400">
                          QUESTION {q.id}
                        </span>
                        <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold ${
                          q.section === 'A'
                            ? 'bg-purple-950/80 text-purple-300 border border-purple-500/30'
                            : 'bg-pink-950/80 text-pink-300 border border-pink-500/30'
                        }`}>
                          {q.sectionTitle.split('–')[0].trim()} • {q.marks} {q.marks === 1 ? 'Mark' : 'Marks'}
                        </span>
                        <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold ${
                          isCorrect ? 'bg-emerald-900/60 text-emerald-300' : 'bg-red-900/60 text-red-300'
                        }`}>
                          {isCorrect ? `+${q.marks} Marks Awarded` : '0 Marks Awarded'}
                        </span>
                      </div>
                      <h4 className="text-sm sm:text-base font-bold text-white leading-snug">
                        {q.question}
                      </h4>
                    </div>
                  </div>

                  <div className="text-slate-400 hover:text-white p-1">
                    {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </div>
                </div>

                {/* Option comparison */}
                <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-slate-800/80 text-xs sm:text-sm">
                  {/* Your Answer */}
                  <div className={`p-3 rounded-xl border flex flex-col justify-between ${
                    isCorrect
                      ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
                      : 'bg-red-950/40 border-red-500/40 text-red-200'
                  }`}>
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 mb-1">
                      Your Selected Answer:
                    </span>
                    <span className="font-semibold text-white">
                      {userOption ? (
                        <span>Option {userAnswer}: {userOption.text}</span>
                      ) : (
                        <span className="text-amber-400 italic">Not Answered</span>
                      )}
                    </span>
                  </div>

                  {/* Correct Answer */}
                  <div className="p-3 rounded-xl border bg-slate-900/80 border-purple-500/30 text-purple-200 flex flex-col justify-between">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-purple-400 mb-1">
                      Official Correct Answer:
                    </span>
                    <span className="font-semibold text-white">
                      Option {q.correctAnswer}: {correctOption?.text}
                    </span>
                  </div>
                </div>

                {/* UX Rationale Explanation */}
                {isExpanded && (
                  <div className="mt-3 p-3.5 bg-slate-950/90 rounded-xl border border-purple-500/20 text-xs text-slate-300 leading-relaxed">
                    <div className="flex items-center gap-1.5 text-purple-400 font-mono font-bold mb-1">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>UX Design Rationale & Principle:</span>
                    </div>
                    <p className="text-slate-300">
                      {q.explanation}
                    </p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-purple-500/20 bg-slate-950/80 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs sm:text-sm uppercase tracking-wider transition"
          >
            Close Review
          </button>
        </div>
      </div>
    </div>
  );
}
