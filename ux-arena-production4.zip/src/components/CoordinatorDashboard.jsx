import React, { useState, useEffect } from 'react';
import { 
  Play, 
  ChevronRight, 
  ChevronLeft, 
  Lock, 
  StopCircle, 
  Trophy, 
  RotateCcw, 
  Users, 
  Clock, 
  ShieldCheck, 
  LogOut, 
  UserMinus, 
  Eye, 
  QrCode, 
  CheckCircle2, 
  AlertTriangle,
  Award,
  Layers,
  Sparkles,
  BarChart3,
  Unlock,
  Radio,
  FileSpreadsheet,
  Pause,
  Send,
  Sliders,
  Maximize2
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { QUESTIONS } from '../data/questions';
import ScoreboardView from './ScoreboardView';
import VisualQuestionRenderer from './VisualQuestionRenderer';
import { sound } from '../utils/sound';

export default function CoordinatorDashboard({
  session,
  participants = [],
  answers = {},
  results,
  onStartQuiz,
  onNextQuestion,
  onPrevQuestion,
  onLockQuestion,
  onPauseQuiz,
  onResumeQuiz,
  onEndQuiz,
  onPreviewResults,
  onPublishResults,
  onResetSession,
  onToggleRegistration,
  onRemoveParticipant,
  onSetQuestionDuration,
  onLogout
}) {
  const [activeTab, setActiveTab] = useState('controls'); // 'controls' | 'participants' | 'scoreboard'
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [showQrModal, setShowQrModal] = useState(false);
  const [durationInput, setDurationInput] = useState(session?.questionDuration || 20);
  const [publishing, setPublishing] = useState(false);
  
  const duration = session?.questionDuration || 20;
  const [timeLeft, setTimeLeft] = useState(session?.timeRemaining ?? duration);

  const currentQIndex = session?.currentQuestionIndex ?? -1;
  const currentQ = currentQIndex >= 0 && currentQIndex < QUESTIONS.length ? QUESTIONS[currentQIndex] : null;

  // Synchronize duration input with session
  useEffect(() => {
    if (session?.questionDuration) {
      setDurationInput(session.questionDuration);
    }
  }, [session?.questionDuration]);

  // Compute live statistics for current question
  const totalParticipants = participants.length;
  let answeredCount = 0;
  let unansweredCount = 0;
  const optionCounts = { A: 0, B: 0, C: 0, D: 0 };

  if (currentQ) {
    participants.forEach((p) => {
      const record = answers[p.id]?.[currentQ.id];
      if (record && record.selectedOption) {
        answeredCount += 1;
        if (optionCounts[record.selectedOption] !== undefined) {
          optionCounts[record.selectedOption] += 1;
        }
      } else {
        unansweredCount += 1;
      }
    });
  }

  // Synchronized timer display for coordinator
  useEffect(() => {
    if (!session || session.status !== 'in_progress' || !session.questionStartedAt || !currentQ) {
      return;
    }

    if (session.isPaused) {
      setTimeLeft(session.timeRemaining ?? 0);
      return;
    }

    const interval = setInterval(() => {
      const now = Date.now();
      const elapsed = (now - session.questionStartedAt) / 1000;
      const qDuration = session.questionDuration || 20;
      const remaining = Math.max(0, Math.ceil(qDuration - elapsed));
      setTimeLeft(remaining);

      // Auto-lock when remaining reaches 0
      if (remaining <= 0 && !session.isLocked) {
        onLockQuestion();
      }
    }, 250);

    return () => clearInterval(interval);
  }, [session?.questionStartedAt, session?.isLocked, session?.isPaused, session?.timeRemaining, session?.status, currentQIndex, onLockQuestion, session?.questionDuration]);

  // Dynamic origin URL for QR code (avoids hardcoded localhost)
  const currentUrl = typeof window !== 'undefined' ? window.location.origin : 'https://ux-arena.netlify.app';
  const isWarning = timeLeft <= 3 && timeLeft > 0;

  const handleDurationChange = (val) => {
    const num = parseInt(val, 10);
    if (!isNaN(num) && num >= 5 && num <= 180) {
      setDurationInput(num);
      onSetQuestionDuration(num);
    }
  };

  const handlePublishResults = async () => {
    setPublishing(true);
    try {
      await onPublishResults();
      setActiveTab('scoreboard');
    } finally {
      setPublishing(false);
    }
  };

  return (
    <div className="relative z-10 max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Top Coordinator Command Header */}
      <div className="glass-panel p-4 sm:p-6 rounded-3xl border-purple-500/30 flex flex-wrap items-center justify-between gap-4 shadow-2xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 via-pink-600 to-blue-600 flex items-center justify-center text-white shadow-lg">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-extrabold text-white font-display">
                Coordinator Command Center
              </h1>
              <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-purple-950/80 border border-purple-500/40 text-purple-300">
                HOST MODE
              </span>
            </div>
            <p className="text-xs font-mono text-slate-400 mt-0.5">
              SPARKLE '26 – UX ARENA: UI/UX BATTLE • Supabase Synchronized
            </p>
          </div>
        </div>

        {/* Room PIN, Duration Selector, QR, and Status Pills */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          {/* Room PIN pill */}
          <div className="bg-slate-900/90 border border-purple-500/30 px-3.5 py-1.5 rounded-xl flex items-center gap-2">
            <span className="text-xs text-slate-400 font-mono">ROOM PIN:</span>
            <span className="font-mono font-bold text-sm text-cyan-400">{session?.pin || 'UX2026'}</span>
          </div>

          {/* Configurable Timer Selector */}
          <div className="bg-slate-900/90 border border-purple-500/30 px-3 py-1.5 rounded-xl flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-purple-400" />
            <span className="text-xs text-slate-400 font-mono">TIMER:</span>
            <select
              value={durationInput}
              disabled={session?.status === 'in_progress'}
              onChange={(e) => handleDurationChange(e.target.value)}
              className="bg-slate-800 text-white font-mono text-xs font-bold rounded px-1.5 py-0.5 border border-purple-500/40 focus:outline-none"
            >
              <option value="15">15s</option>
              <option value="20">20s (Default)</option>
              <option value="30">30s</option>
              <option value="45">45s</option>
              <option value="60">60s</option>
            </select>
          </div>

          {/* QR Code toggle */}
          <button
            onClick={() => setShowQrModal(true)}
            className="p-2 rounded-xl bg-slate-900 border border-purple-500/30 hover:border-cyan-400 text-cyan-300 transition cursor-pointer"
            title="Display Session QR Code"
          >
            <QrCode className="w-4 h-4" />
          </button>

          {/* Registration toggle */}
          <button
            onClick={() => onToggleRegistration(!session?.registrationOpen)}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold border transition cursor-pointer ${
              session?.registrationOpen
                ? 'bg-emerald-950/70 border-emerald-500/40 text-emerald-300 hover:bg-emerald-900/50'
                : 'bg-red-950/70 border-red-500/40 text-red-300 hover:bg-red-900/50'
            }`}
          >
            {session?.registrationOpen ? 'Registration: OPEN' : 'Registration: CLOSED'}
          </button>

          {/* Logout */}
          <button
            onClick={onLogout}
            className="p-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-red-500 text-slate-400 hover:text-red-400 transition cursor-pointer"
            title="Coordinator Logout"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-purple-500/20 pb-2">
        <button
          onClick={() => setActiveTab('controls')}
          className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-mono font-bold transition flex items-center gap-2 cursor-pointer ${
            activeTab === 'controls'
              ? 'bg-purple-600 text-white shadow-glow-purple'
              : 'bg-slate-900/80 text-slate-400 hover:text-white'
          }`}
        >
          <Radio className="w-4 h-4" />
          <span>Live Battle Controls</span>
        </button>

        <button
          onClick={() => setActiveTab('participants')}
          className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-mono font-bold transition flex items-center gap-2 cursor-pointer ${
            activeTab === 'participants'
              ? 'bg-purple-600 text-white shadow-glow-purple'
              : 'bg-slate-900/80 text-slate-400 hover:text-white'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Participants ({participants.length})</span>
        </button>

        <button
          onClick={() => {
            if (!results && session?.status === 'completed') {
              onPreviewResults();
            }
            setActiveTab('scoreboard');
          }}
          className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-mono font-bold transition flex items-center gap-2 cursor-pointer ${
            activeTab === 'scoreboard'
              ? 'bg-pink-600 text-white shadow-glow-pink'
              : 'bg-slate-900/80 text-slate-400 hover:text-white'
          }`}
        >
          <Trophy className="w-4 h-4" />
          <span>Scoreboard {session?.resultsPublished ? '✓ Published' : results ? '• Preview' : '(Locked)'}</span>
        </button>
      </div>

      {/* TAB 1: LIVE BATTLE CONTROLS */}
      {activeTab === 'controls' && (
        <div className="space-y-6">
          {/* Main Control Panel Card */}
          <div className="glass-panel p-6 rounded-3xl border-purple-500/30 shadow-xl">
            {/* Top Status & Question Counter */}
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-purple-500/20">
              <div className="flex items-center gap-3">
                <span className={`px-3 py-1 rounded-xl text-xs font-mono font-bold uppercase tracking-wider ${
                  session?.status === 'in_progress'
                    ? session?.isPaused
                      ? 'bg-amber-950/80 text-amber-300 border border-amber-500/40 animate-pulse'
                      : 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/40 animate-pulse'
                    : session?.status === 'completed'
                    ? 'bg-pink-950/80 text-pink-300 border border-pink-500/40'
                    : session?.status === 'finalized'
                    ? 'bg-purple-950/80 text-purple-300 border border-purple-500/40'
                    : 'bg-slate-900 text-slate-400 border border-slate-700'
                }`}>
                  STATUS: {session?.isPaused ? 'PAUSED' : session?.status}
                </span>

                {currentQ && (
                  <span className={`px-3 py-1 rounded-xl text-xs font-mono font-bold ${
                    currentQ.section === 'A'
                      ? 'bg-purple-950/80 text-purple-300 border border-purple-500/40'
                      : 'bg-pink-950/80 text-pink-300 border border-pink-500/40'
                  }`}>
                    {currentQ.sectionTitle} • {currentQ.marks} {currentQ.marks === 1 ? 'Mark' : 'Marks'}
                  </span>
                )}
              </div>

              {/* Countdown Timer Display */}
              {session?.status === 'in_progress' && (
                <div className={`flex items-center gap-3 px-4 py-2 rounded-2xl border ${
                  session?.isPaused
                    ? 'bg-amber-950/80 border-amber-500 text-amber-300'
                    : isWarning 
                    ? 'bg-red-950/80 border-red-500 text-red-300 animate-timer-warning' 
                    : 'bg-slate-900 border-purple-500/40 text-white shadow-glow-purple'
                }`}>
                  <Clock className={`w-5 h-5 ${session?.isPaused ? 'text-amber-400' : isWarning ? 'text-red-400' : 'text-purple-400'}`} />
                  <div>
                    <span className="text-[10px] font-mono text-slate-400 uppercase block">
                      {session?.isPaused ? 'Timer PAUSED' : `${duration}s Sync Timer`}
                    </span>
                    <span className="font-mono font-extrabold text-xl">{timeLeft}s remaining</span>
                  </div>
                </div>
              )}
            </div>

            {/* Battle Control Action Bar */}
            <div className="my-6 flex flex-wrap items-center gap-3">
              {session?.status === 'registration' && (
                <button
                  type="button"
                  onClick={() => onStartQuiz(durationInput)}
                  className="px-6 py-3.5 rounded-xl font-display font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-purple-900/50 hover:shadow-glow-purple transition cursor-pointer active:scale-95"
                  style={{ background: 'linear-gradient(135deg, #8b5cf6 0%, #ec4899 100%)' }}
                >
                  <Play className="w-5 h-5 fill-white" />
                  <span>START QUIZ (RELEASE Q1 • {durationInput}s)</span>
                </button>
              )}

              {session?.status === 'in_progress' && (
                <>
                  {/* Prev Question */}
                  <button
                    type="button"
                    onClick={onPrevQuestion}
                    disabled={currentQIndex === 0}
                    className={`px-4 py-3 rounded-xl text-xs font-mono uppercase tracking-wider flex items-center gap-2 border transition ${
                      currentQIndex === 0
                        ? 'opacity-40 cursor-not-allowed bg-slate-900 border-slate-800 text-slate-500'
                        : 'bg-slate-900 border-purple-500/40 hover:border-purple-300 text-slate-200 cursor-pointer'
                    }`}
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span>PREV QUESTION</span>
                  </button>

                  {/* PAUSE / RESUME QUIZ BUTTON */}
                  {session?.isPaused ? (
                    <button
                      onClick={onResumeQuiz}
                      className="px-5 py-3 rounded-xl text-xs font-mono font-bold uppercase tracking-wider bg-emerald-600 hover:bg-emerald-500 text-white flex items-center gap-2 shadow-lg shadow-emerald-900/40 transition cursor-pointer"
                    >
                      <Play className="w-4 h-4 fill-white" />
                      <span>RESUME QUIZ</span>
                    </button>
                  ) : (
                    <button
                      onClick={onPauseQuiz}
                      disabled={session?.isLocked}
                      className="px-5 py-3 rounded-xl text-xs font-mono uppercase tracking-wider bg-slate-900 border border-purple-500/40 hover:border-amber-400 text-purple-200 hover:text-amber-300 flex items-center gap-2 transition cursor-pointer"
                    >
                      <Pause className="w-4 h-4" />
                      <span>PAUSE QUIZ</span>
                    </button>
                  )}

                  {/* Next Question */}
                  <button
                    onClick={onNextQuestion}
                    className="px-6 py-3 rounded-xl font-display font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2 shadow-lg transition hover:scale-[1.02] cursor-pointer"
                    style={{ background: 'linear-gradient(135deg, #8b5cf6 0%, #3b82f6 100%)' }}
                  >
                    <span>{currentQIndex === QUESTIONS.length - 1 ? 'COMPLETE QUIZ' : `NEXT QUESTION (${duration}s)`}</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>

                  {/* End Quiz button */}
                  <button
                    onClick={onEndQuiz}
                    className="px-4 py-3 rounded-xl text-xs font-mono uppercase tracking-wider bg-red-950/60 border border-red-500/40 text-red-300 hover:bg-red-900/60 transition flex items-center gap-2 cursor-pointer ml-auto"
                  >
                    <StopCircle className="w-4 h-4" />
                    <span>END QUIZ</span>
                  </button>
                </>
              )}

              {/* Status Completed: Preview and Publish Flow */}
              {session?.status === 'completed' && (
                <div className="flex flex-wrap items-center gap-3">
                  <button
                    onClick={() => {
                      onPreviewResults();
                      setActiveTab('scoreboard');
                    }}
                    className="px-5 py-3 rounded-xl font-display font-bold text-xs uppercase tracking-wider bg-slate-900 border border-purple-500/50 hover:border-purple-300 text-purple-300 hover:text-white flex items-center gap-2 transition cursor-pointer"
                  >
                    <Eye className="w-4 h-4" />
                    <span>PREVIEW RESULTS</span>
                  </button>

                  <button
                    onClick={handlePublishResults}
                    disabled={publishing}
                    className="px-6 py-3.5 rounded-xl font-display font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-pink-900/50 hover:shadow-glow-pink transition cursor-pointer animate-pulse"
                    style={{ background: 'linear-gradient(135deg, #ec4899 0%, #8b5cf6 100%)' }}
                  >
                    <Send className="w-4 h-4" />
                    <span>{publishing ? 'PUBLISHING...' : 'PUBLISH RESULTS TO PARTICIPANTS'}</span>
                  </button>
                </div>
              )}

              {/* Status Finalized / Published */}
              {session?.status === 'finalized' && (
                <div className="flex items-center gap-3">
                  <span className="px-4 py-2 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-mono font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Results Officially Published Live</span>
                  </span>
                  <button
                    onClick={() => setActiveTab('scoreboard')}
                    className="px-4 py-2 rounded-xl bg-pink-600 hover:bg-pink-500 text-white text-xs font-mono font-bold transition"
                  >
                    View Scoreboard
                  </button>
                </div>
              )}

              {/* Reset Session Action */}
              <button
                onClick={() => setShowResetConfirm(true)}
                className="px-4 py-3 rounded-xl text-xs font-mono uppercase tracking-wider bg-slate-900 border border-slate-700 text-slate-400 hover:text-white hover:border-purple-500 transition flex items-center gap-2 cursor-pointer ml-auto"
              >
                <RotateCcw className="w-4 h-4" />
                <span>RESET SESSION</span>
              </button>
            </div>

            {/* Live Real-Time Participant Response Stats */}
            {currentQ && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-purple-500/20">
                <div className="p-4 rounded-xl bg-slate-950/80 border border-purple-500/20 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-mono text-slate-400 uppercase">Joined Participants</span>
                    <span className="text-2xl font-bold text-white font-mono block mt-1">{totalParticipants}</span>
                  </div>
                  <Users className="w-6 h-6 text-purple-400" />
                </div>

                <div className="p-4 rounded-xl bg-slate-950/80 border border-emerald-500/20 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-mono text-slate-400 uppercase">Answers Submitted</span>
                    <span className="text-2xl font-bold text-emerald-400 font-mono block mt-1">
                      {answeredCount} <span className="text-xs text-slate-500 font-normal">/ {totalParticipants}</span>
                    </span>
                  </div>
                  <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                </div>

                <div className="p-4 rounded-xl bg-slate-950/80 border border-pink-500/20 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-mono text-slate-400 uppercase">Pending / Unanswered</span>
                    <span className="text-2xl font-bold text-pink-400 font-mono block mt-1">
                      {unansweredCount} <span className="text-xs text-slate-500 font-normal">/ {totalParticipants}</span>
                    </span>
                  </div>
                  <Clock className="w-6 h-6 text-pink-400" />
                </div>
              </div>
            )}

            {/* Live Option Response Breakdown (Coordinator Only) */}
            {currentQ && (
              <div className="mt-4 p-4 rounded-xl bg-slate-950/60 border border-slate-800">
                <span className="text-xs font-mono text-purple-400 font-bold block mb-2">
                  LIVE RESPONSE TALLY (Q{currentQ.id}):
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
                  {['A', 'B', 'C', 'D'].map((opt) => (
                    <div key={opt} className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
                      <span className="text-slate-300 font-bold">Option {opt}:</span>
                      <span className="text-purple-300 font-extrabold text-sm">{optionCounts[opt]} votes</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Current Question Inspector Preview */}
          {currentQ && (
            <div className="glass-panel p-6 rounded-3xl border-purple-500/30">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono text-purple-400 uppercase font-bold">
                  PROJECTOR PREVIEW: QUESTION {currentQIndex + 1} of {QUESTIONS.length}
                </span>
                <span className="text-xs font-mono text-pink-300 font-bold">
                  Correct Answer: Option {currentQ.correctAnswer} (Hidden from participants)
                </span>
              </div>

              <h3 className="text-xl sm:text-2xl font-bold text-white mb-4">
                {currentQ.question}
              </h3>

              <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 mb-4">
                <VisualQuestionRenderer question={currentQ} />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                {currentQ.options.map((opt) => (
                  <div
                    key={opt.id}
                    className={`p-3.5 rounded-xl border flex items-center justify-between ${
                      opt.id === currentQ.correctAnswer
                        ? 'bg-purple-950/40 border-purple-500 text-white font-bold'
                        : 'bg-slate-900/60 border-slate-800 text-slate-300'
                    }`}
                  >
                    <span>Option {opt.id}: {opt.text}</span>
                    {opt.id === currentQ.correctAnswer && (
                      <span className="text-[10px] font-mono bg-purple-500 text-white px-2 py-0.5 rounded">
                        CORRECT
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: PARTICIPANTS ROSTER */}
      {activeTab === 'participants' && (
        <div className="glass-panel p-6 rounded-3xl border-purple-500/30 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-bold text-white">Connected Contenders ({participants.length})</h3>
              <p className="text-xs text-slate-400">Coordinators can inspect and remove invalid or duplicate participants.</p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead>
                <tr className="bg-slate-950/80 text-slate-400 font-mono uppercase text-[11px] border-b border-purple-500/20">
                  <th className="py-3 px-4">#</th>
                  <th className="py-3 px-4">Contender Name</th>
                  <th className="py-3 px-4">Team Name</th>
                  <th className="py-3 px-4">Joined At</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {participants.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-slate-500 font-mono">
                      No participants joined yet. Share Room PIN: <strong className="text-cyan-400">{session?.pin}</strong>
                    </td>
                  </tr>
                ) : (
                  participants.map((p, idx) => (
                    <tr key={p.id} className="hover:bg-purple-950/20">
                      <td className="py-3 px-4 font-mono text-slate-500">{idx + 1}</td>
                      <td className="py-3 px-4 font-bold text-white">{p.name}</td>
                      <td className="py-3 px-4 text-purple-300 font-mono">{p.teamName}</td>
                      <td className="py-3 px-4 text-slate-400 font-mono text-xs">
                        {new Date(p.joinedAt).toLocaleTimeString()}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => onRemoveParticipant(p.id)}
                          className="px-2.5 py-1 rounded bg-red-950/60 border border-red-500/40 hover:bg-red-900/60 text-red-300 text-xs font-mono transition cursor-pointer"
                        >
                          Remove
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: SCOREBOARD */}
      {activeTab === 'scoreboard' && (
        <div className="space-y-4">
          {results ? (
            <ScoreboardView
              results={results}
              session={session}
              onResetSession={onResetSession}
              isCoordinatorView={true}
              onPublishResults={handlePublishResults}
              publishing={publishing}
            />
          ) : (
            <div className="glass-panel p-12 rounded-3xl border-purple-500/30 text-center">
              <Trophy className="w-12 h-12 text-slate-600 mx-auto mb-3" />
              <h3 className="text-xl font-bold text-white">Scoreboard Not Yet Generated</h3>
              <p className="text-xs text-slate-400 max-w-md mx-auto mt-1 leading-relaxed">
                As per competition rules, scores are strictly confidential during the battle.
                Once questions are completed, generate a preview or publish the scoreboard.
              </p>
              {session?.status === 'completed' && (
                <div className="mt-6 flex justify-center gap-3">
                  <button
                    onClick={() => {
                      onPreviewResults();
                    }}
                    className="px-6 py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs uppercase font-mono tracking-wider transition cursor-pointer"
                  >
                    Generate Scoreboard Preview
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* QR Code Modal for Coordinator Projection */}
      {showQrModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
          <div className="glass-panel p-6 sm:p-8 rounded-3xl max-w-sm w-full border-2 border-purple-500/40 text-center relative shadow-2xl">
            <h3 className="text-lg font-bold text-white font-display mb-1">Join SPARKLE '26 Battle</h3>
            <p className="text-xs font-mono text-purple-300 mb-4">Scan or enter Room PIN</p>
            <div className="p-4 bg-white rounded-2xl mx-auto inline-block shadow-2xl">
              <QRCodeSVG value={currentUrl} size={180} />
            </div>
            <div className="mt-4 p-3 bg-slate-950 rounded-xl border border-purple-500/30">
              <span className="text-xs text-slate-400 block font-mono">ROOM PIN</span>
              <span className="text-3xl font-extrabold text-cyan-400 font-mono tracking-widest">{session?.pin}</span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono mt-2 break-all">{currentUrl}</p>
            <button
              onClick={() => setShowQrModal(false)}
              className="mt-5 w-full py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-mono uppercase cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Session Reset Confirmation Modal */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
          <div className="glass-panel p-6 sm:p-8 rounded-3xl max-w-md w-full border-2 border-red-500/50 shadow-glow-pink">
            <div className="flex items-center gap-3 text-red-400 mb-3">
              <AlertTriangle className="w-8 h-8" />
              <h3 className="text-lg font-bold text-white">Reset Quiz Session?</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              This will wipe all current participants, answers, and scores, resetting the room for a fresh round. This action is irreversible.
            </p>
            <div className="mt-6 flex items-center justify-end gap-3">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 text-xs font-mono cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setShowResetConfirm(false);
                  onResetSession();
                }}
                className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs font-mono cursor-pointer"
              >
                Yes, Reset Session
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
