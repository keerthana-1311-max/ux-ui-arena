export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: { extend: {
    fontFamily: { display: ['Space Grotesk', 'sans-serif'], mono: ['JetBrains Mono', 'monospace'], sans: ['Inter', 'system-ui', 'sans-serif'] },
    boxShadow: { 'glow-purple': '0 0 24px rgba(139,92,246,.35)', 'glow-pink': '0 0 24px rgba(236,72,153,.35)', 'glow-blue': '0 0 24px rgba(59,130,246,.35)' },
    keyframes: {
      fadeIn: { from: { opacity: 0, transform: 'translateY(6px)' }, to: { opacity: 1, transform: 'none' } },
      pulseGlow: { '0%,100%': { opacity: .15 }, '50%': { opacity: .3 } },
      float: { '0%,100%': { transform: 'translateY(0) rotate(45deg)' }, '50%': { transform: 'translateY(-18px) rotate(45deg)' } },
      floatReverse: { '0%,100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(16px)' } },
      timerWarning: { '0%,100%': { transform: 'scale(1)' }, '50%': { transform: 'scale(1.06)' } },
      floatUp: { from: { transform: 'translateY(0) scale(.8)', opacity: 1 }, to: { transform: 'translateY(-80vh) scale(1.3)', opacity: 0 } },
    },
    animation: { fadeIn: 'fadeIn .4s ease-out', 'pulse-glow': 'pulseGlow 6s ease-in-out infinite', float: 'float 9s ease-in-out infinite', 'float-reverse': 'floatReverse 11s ease-in-out infinite', 'timer-warning': 'timerWarning .6s ease-in-out infinite', 'float-up': 'floatUp 3.2s ease-out forwards' },
  } },
};
