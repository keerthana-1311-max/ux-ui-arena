import React, { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Sparkles, Users, ArrowRight, ShieldAlert, KeyRound, QrCode } from 'lucide-react';
import { DEFAULT_PIN } from '../lib/realtimeSync';

export default function JoinQuizModal({ onJoinSuccess, session, onOpenCoordinatorLogin }) {
  const [name, setName] = useState('');
  const [teamName, setTeamName] = useState('');
  const [pin, setPin] = useState(session?.pin || DEFAULT_PIN);
  const [showQrModal, setShowQrModal] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const currentUrl = typeof window !== 'undefined' ? window.location.origin : 'https://ux-arena.netlify.app';

  const handleJoin = async (e) => {
    e.preventDefault();
    setError('');

    const targetPin = (session?.pin || DEFAULT_PIN).toUpperCase();
    if (pin.trim().toUpperCase() !== targetPin) {
      setError(`Invalid session PIN. Please enter the active room PIN provided by the coordinator (${targetPin}).`);
      return;
    }

    if (!session?.registrationOpen) {
      setError('Registration is currently closed for this round. Please contact the event coordinator.');
      return;
    }

    if (!name.trim() || !teamName.trim()) {
      setError('Please provide both your Contender Name and Team/College Name.');
      return;
    }

    setLoading(true);
    try {
      await onJoinSuccess({
        name: name.trim(),
        teamName: teamName.trim(),
        pin: pin.trim().toUpperCase()
      });
    } catch (err) {
      setError(err?.message || 'Failed to join session. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative z-10 max-w-4xl mx-auto px-4 py-8 sm:py-12 flex flex-col items-center justify-center min-h-[calc(100vh-80px)]">
      {/* Top Fest Badge */}
      <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-gradient-to-r from-purple-500/10 via-pink-500/10 to-blue-500/10 border border-purple-500/30 text-purple-300 text-xs sm:text-sm font-mono uppercase tracking-widest mb-4 animate-pulse">
        <Sparkles className="w-4 h-4 text-pink-400" />
        <span>SPARKLE '26 • TECHNICAL FEST</span>
        <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
        <span className="text-cyan-400 font-semibold">ROUND 1 BATTLE</span>
      </div>

      {/* Main Hero Title */}
      <div className="text-center space-y-2 max-w-2xl">
        <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight font-display">
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 filter drop-shadow-[0_0_35px_rgba(168,85,247,0.35)]">
            UX ARENA
          </span>
        </h1>
        <p className="text-base sm:text-xl font-bold tracking-widest text-slate-200 uppercase font-mono">
          UI/UX BATTLE – LIVE ARENA
        </p>
        <p className="text-sm text-slate-400 max-w-lg mx-auto">
          Coordinator-Controlled Live Competition. Enter the arena session PIN to connect your device.
        </p>
      </div>

      {/* Registration Card */}
      <div className="w-full max-w-lg mt-8 glass-panel p-6 sm:p-8 rounded-3xl border-2 border-purple-500/30 shadow-glow-purple relative">
        <div className="flex items-center justify-between pb-4 mb-4 border-b border-purple-500/20">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-purple-400" />
            <h3 className="text-base font-bold text-white">Participant Check-in</h3>
          </div>
          <button
            onClick={() => setShowQrModal(!showQrModal)}
            className="flex items-center gap-1.5 text-xs font-mono text-cyan-300 hover:text-cyan-200 bg-cyan-950/60 border border-cyan-500/30 px-3 py-1.5 rounded-xl transition cursor-pointer"
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>{showQrModal ? 'Hide QR' : 'Share QR'}</span>
          </button>
        </div>

        {/* QR Code expansion */}
        {showQrModal && (
          <div className="mb-6 p-4 bg-slate-950/90 border border-cyan-500/30 rounded-2xl flex flex-col items-center text-center animate-fadeIn">
            <div className="p-3 bg-white rounded-xl shadow-lg">
              <QRCodeSVG value={currentUrl} size={150} />
            </div>
            <p className="text-xs text-slate-300 mt-2 font-mono">
              Scan to join on mobile or use PIN: <strong className="text-cyan-400 text-sm">{session?.pin || DEFAULT_PIN}</strong>
            </p>
            <p className="text-[10px] text-slate-500 font-mono mt-1 break-all">{currentUrl}</p>
          </div>
        )}

        {error && (
          <div className="mb-4 p-3 bg-red-950/60 border border-red-500/40 rounded-xl text-xs text-red-300 flex items-start gap-2">
            <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5 text-red-400" />
            <span>{error}</span>
          </div>
        )}

        {/* Check-in Form */}
        <form onSubmit={handleJoin} className="space-y-4">
          <div>
            <label className="block text-xs font-mono text-slate-300 mb-1 flex items-center justify-between">
              <span>Session PIN:</span>
              <span className="text-[11px] text-purple-400">Current Room: {session?.pin || DEFAULT_PIN}</span>
            </label>
            <div className="relative">
              <input
                type="text"
                required
                value={pin}
                onChange={(e) => setPin(e.target.value.toUpperCase())}
                placeholder="UX2026"
                className="w-full bg-slate-900/90 border border-purple-500/40 rounded-xl px-4 py-2.5 text-sm font-mono tracking-widest text-white uppercase placeholder-slate-500 focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400 transition"
                maxLength={10}
              />
              <KeyRound className="w-4 h-4 text-purple-400 absolute right-3.5 top-3" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-300 mb-1">
              Participant Name:
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Alex Morgan"
              className="w-full bg-slate-900/90 border border-purple-500/40 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400 transition"
              maxLength={40}
            />
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-300 mb-1">
              Team / College Name:
            </label>
            <input
              type="text"
              required
              value={teamName}
              onChange={(e) => setTeamName(e.target.value)}
              placeholder="e.g. Team Pixel / St. Joseph's College"
              className="w-full bg-slate-900/90 border border-purple-500/40 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400 transition"
              maxLength={50}
            />
          </div>

          <button
            type="submit"
            disabled={loading || !session?.registrationOpen}
            className="w-full mt-2 py-3.5 rounded-xl font-display font-bold text-sm sm:text-base tracking-wider uppercase text-white shadow-lg shadow-purple-900/50 hover:shadow-glow-purple transition-all duration-300 flex items-center justify-center gap-2 group cursor-pointer disabled:opacity-50"
            style={{
              background: 'linear-gradient(135deg, #8b5cf6 0%, #ec4899 50%, #3b82f6 100%)'
            }}
          >
            <span>{loading ? 'CONNECTING...' : 'JOIN UX ARENA BATTLE'}</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </form>

        {/* Footer with Coordinator Link */}
        <div className="mt-6 pt-4 border-t border-purple-500/20 flex items-center justify-between text-xs font-mono text-slate-400">
          <span>Are you an event organizer?</span>
          <button
            onClick={onOpenCoordinatorLogin}
            className="text-pink-400 hover:text-pink-300 font-bold hover:underline cursor-pointer"
          >
            Coordinator Sign In →
          </button>
        </div>
      </div>
    </div>
  );
}
