import React, { useState, useEffect } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Send, 
  Check, 
  HelpCircle, 
  AlertCircle, 
  CheckCircle2, 
  Award,
  Sparkles,
  Layers,
  ArrowRight
} from 'lucide-react';
import VisualQuestionRenderer from './VisualQuestionRenderer';
import { sound } from '../utils/sound';

export default function QuizScreen({
  questions,
  currentQuestionIndex,
  answers,
  onSelectOption,
  onNextQuestion,
  onPrevQuestion,
  onJumpToQuestion,
  onSubmitQuiz,
  timeLeft
}) {
  const [showSubmitModal, setShowSubmitModal] = useState(false);

  const currentQ = questions[currentQuestionIndex];
  const selectedOptionId = answers[currentQ.id];
  const totalQuestions = questions.length;
  const answeredCount = Object.keys(answers).length;
  const unansweredCount = totalQuestions - answeredCount;

  // Keyboard navigation support (A, B, C, D or 1, 2, 3, 4)
  useEffect(() => {
    const handleKeyDown = (e) => {
      // Don't trigger if user is typing in an input
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

      const key = e.key.toUpperCase();
      if (['A', 'B', 'C', 'D'].includes(key)) {
        sound.playSelect();
        onSelectOption(currentQ.id, key);
      } else if (['1', '2', '3', '4'].includes(e.key)) {
        const map = { '1': 'A', '2': 'B', '3': 'C', '4': 'D' };
        sound.playSelect();
        onSelectOption(currentQ.id, map[e.key]);
      } else if (e.key === 'ArrowRight') {
        if (currentQuestionIndex < totalQuestions - 1) {
          sound.playNext();
          onNextQuestion();
        }
      } else if (e.key === 'ArrowLeft') {
        if (currentQuestionIndex > 0) {
          sound.playNext();
          onPrevQuestion();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentQ.id, currentQuestionIndex, totalQuestions, onSelectOption, onNextQuestion, onPrevQuestion]);

  const handleOptionClick = (optionId) => {
    sound.playSelect();
    onSelectOption(currentQ.id, optionId);
  };

  const handleNextClick = () => {
    sound.playNext();
    if (currentQuestionIndex === totalQuestions - 1) {
      setShowSubmitModal(true);
    } else {
      onNextQuestion();
    }
  };

  const handlePrevClick = () => {
    sound.playNext();
    onPrevQuestion();
  };

  const handleConfirmSubmit = () => {
    sound.playVictory();
    setShowSubmitModal(false);
    onSubmitQuiz();
  };

  const progressPercentage = ((currentQuestionIndex + 1) / totalQuestions) * 100;

  return (
    <div className="relative z-10 max-w-5xl mx-auto px-4 py-4 sm:py-6 flex flex-col justify-between min-h-[calc(100vh-80px)]">
      {/* Top Question Progress & Meta Bar */}
      <div>
        <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
          {/* Section Indicator */}
          <div className="flex items-center gap-2">
            <span className={`text-xs sm:text-sm font-mono font-bold px-3 py-1 rounded-xl border flex items-center gap-1.5 ${
              currentQ.section === 'A'
                ? 'bg-purple-950/70 border-purple-500/40 text-purple-300 shadow-glow-purple'
                : 'bg-pink-950/70 border-pink-500/40 text-pink-300 shadow-glow-pink'
            }`}>
              <Layers className="w-3.5 h-3.5" />
              <span>{currentQ.sectionTitle}</span>
            </span>

            <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 flex items-center gap-1">
              <Award className="w-3.5 h-3.5 text-yellow-400" />
              <span>{currentQ.marks} {currentQ.marks === 1 ? 'Mark' : 'Marks'}</span>
            </span>
          </div>

          {/* Quick Counter */}
          <div className="flex items-center gap-3 text-xs sm:text-sm font-mono text-slate-400">
            <span>
              Question <strong className="text-white text-base">{currentQuestionIndex + 1}</strong> of <strong className="text-white text-base">{totalQuestions}</strong>
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-slate-700 hidden sm:inline-block" />
            <span className="text-purple-300 hidden sm:inline-block">
              {answeredCount} Answered
            </span>
          </div>
        </div>

        {/* Smooth Linear Progress Bar */}
        <div className="w-full bg-slate-900/90 h-2 rounded-full overflow-hidden border border-slate-800 p-0.5">
          <div 
            className="h-full rounded-full transition-all duration-500 ease-out"
            style={{ 
              width: `${progressPercentage}%`,
              background: 'linear-gradient(90deg, #8b5cf6 0%, #ec4899 50%, #3b82f6 100%)',
              boxShadow: '0 0 12px rgba(168, 85, 247, 0.6)'
            }}
          />
        </div>
      </div>

      {/* Main Question Card with Glassmorphism */}
      <div className="my-4 glass-panel rounded-3xl p-5 sm:p-8 border-purple-500/25 shadow-2xl relative overflow-hidden transition-all duration-300">
        {/* Subtle background highlight for the active question */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-purple-600/5 rounded-full blur-3xl pointer-events-none" />

        {/* Question Title & Prompt */}
        <div className="mb-4">
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-xs font-mono tracking-wider uppercase text-purple-400 font-bold bg-purple-500/10 px-2.5 py-0.5 rounded-md border border-purple-500/30">
              Q{currentQ.id} • {currentQ.title}
            </span>
          </div>

          <h2 className="text-xl sm:text-2xl md:text-3xl font-extrabold text-white tracking-tight leading-snug">
            {currentQ.question}
          </h2>
        </div>

        {/* Custom Visual Asset Container */}
        <div className="my-4 bg-slate-950/70 border border-slate-800/80 rounded-2xl p-2 sm:p-4 backdrop-blur-sm shadow-inner">
          <VisualQuestionRenderer question={currentQ} />
        </div>

        {/* Four Selectable Options */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 mt-6">
          {currentQ.options.map((option) => {
            const isSelected = selectedOptionId === option.id;

            return (
              <button
                key={option.id}
                onClick={() => handleOptionClick(option.id)}
                className={`relative text-left p-4 sm:p-5 rounded-2xl transition-all duration-200 flex items-center justify-between group cursor-pointer ${
                  isSelected
                    ? 'glass-card-active scale-[1.01]'
                    : 'glass-panel glass-panel-hover border-slate-800'
                }`}
              >
                <div className="flex items-center gap-3.5">
                  {/* Option Letter Indicator */}
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-mono font-bold text-sm shrink-0 transition-all duration-200 ${
                    isSelected
                      ? 'bg-gradient-to-tr from-purple-500 to-pink-500 text-white shadow-glow-purple'
                      : 'bg-slate-800/90 text-slate-300 border border-slate-700 group-hover:border-purple-400 group-hover:text-white'
                  }`}>
                    {option.id}
                  </div>

                  {/* Option Text */}
                  <span className={`text-sm sm:text-base font-semibold leading-relaxed transition-colors ${
                    isSelected ? 'text-white font-bold' : 'text-slate-200 group-hover:text-white'
                  }`}>
                    {option.text}
                  </span>
                </div>

                {/* Right Selection Radio Circle */}
                <div className={`w-6 h-6 rounded-full flex items-center justify-center border-2 transition-all shrink-0 ml-3 ${
                  isSelected
                    ? 'border-purple-400 bg-purple-500 text-white shadow-glow-purple'
                    : 'border-slate-700 group-hover:border-slate-500'
                }`}>
                  {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                </div>
              </button>
            );
          })}
        </div>

        {/* Keyboard shortcut hint */}
        <div className="mt-5 flex items-center justify-between text-xs text-slate-400 font-mono">
          <span className="hidden sm:inline">
            Tip: Press <kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-300">A</kbd> <kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-300">B</kbd> <kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-300">C</kbd> <kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-300">D</kbd> to select
          </span>
          <span>
            {selectedOptionId ? (
              <span className="text-emerald-400 font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Option {selectedOptionId} Selected
              </span>
            ) : (
              <span className="text-amber-400 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" /> Choose an option to proceed
              </span>
            )}
          </span>
        </div>
      </div>

      {/* Bottom Navigation & Question Drawer Bar */}
      <div className="pt-2">
        {/* Interactive Question Jump Strip */}
        <div className="flex items-center justify-center gap-1.5 sm:gap-2 mb-4 overflow-x-auto py-1">
          {questions.map((q, idx) => {
            const isCurrent = idx === currentQuestionIndex;
            const isAnswered = !!answers[q.id];

            return (
              <button
                key={q.id}
                onClick={() => {
                  sound.playSelect();
                  onJumpToQuestion(idx);
                }}
                className={`w-8 h-8 sm:w-9 sm:h-9 rounded-xl font-mono text-xs font-bold transition-all duration-200 flex items-center justify-center relative ${
                  isCurrent
                    ? 'bg-purple-600 text-white shadow-glow-purple border-2 border-white scale-110'
                    : isAnswered
                    ? 'bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 hover:border-emerald-400'
                    : 'bg-slate-900 border border-slate-800 text-slate-400 hover:border-slate-600 hover:text-slate-200'
                }`}
                title={`Jump to Q${q.id} (${q.sectionTitle} - ${isAnswered ? 'Answered' : 'Unanswered'})`}
              >
                {q.id}
                {isAnswered && !isCurrent && (
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 absolute bottom-1 right-1" />
                )}
              </button>
            );
          })}
        </div>

        {/* Action Controls: Previous, Question Progress, Next / Submit */}
        <div className="flex items-center justify-between gap-3">
          <button
            onClick={handlePrevClick}
            disabled={currentQuestionIndex === 0}
            className={`px-4 sm:px-6 py-3 rounded-xl font-semibold text-xs sm:text-sm font-mono uppercase tracking-wider flex items-center gap-2 transition-all ${
              currentQuestionIndex === 0
                ? 'opacity-30 cursor-not-allowed bg-slate-900 border border-slate-800 text-slate-500'
                : 'glass-panel glass-panel-hover border-purple-500/30 text-slate-200 hover:text-white'
            }`}
          >
            <ChevronLeft className="w-4 h-4" />
            <span className="hidden sm:inline">PREVIOUS</span>
            <span className="sm:hidden">PREV</span>
          </button>

          {/* Quick Submit button if all answered or user wants to submit early */}
          <button
            onClick={() => setShowSubmitModal(true)}
            className="px-4 py-2.5 rounded-xl bg-slate-900/80 border border-purple-500/30 hover:border-pink-500/50 text-xs font-mono text-slate-300 hover:text-pink-300 transition-all flex items-center gap-1.5"
          >
            <Send className="w-3.5 h-3.5 text-pink-400" />
            <span>FINISH & SUBMIT</span>
          </button>

          {currentQuestionIndex < totalQuestions - 1 ? (
            <button
              onClick={handleNextClick}
              className="px-5 sm:px-8 py-3 rounded-xl font-display font-bold text-xs sm:text-sm tracking-wider uppercase text-white shadow-lg transition-all duration-300 flex items-center gap-2 group hover:scale-[1.02] active:scale-[0.98]"
              style={{
                background: 'linear-gradient(135deg, #8b5cf6 0%, #3b82f6 100%)',
                boxShadow: '0 0 20px rgba(139, 92, 246, 0.4)'
              }}
            >
              <span>NEXT</span>
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          ) : (
            <button
              onClick={() => setShowSubmitModal(true)}
              className="px-5 sm:px-8 py-3 rounded-xl font-display font-bold text-xs sm:text-sm tracking-wider uppercase text-white shadow-lg transition-all duration-300 flex items-center gap-2 group hover:scale-[1.02] active:scale-[0.98] animate-pulse"
              style={{
                background: 'linear-gradient(135deg, #ec4899 0%, #8b5cf6 100%)',
                boxShadow: '0 0 25px rgba(236, 72, 153, 0.5)'
              }}
            >
              <span>SUBMIT BATTLE</span>
              <Send className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Confirmation Modal before Final Submission */}
      {showSubmitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div className="glass-panel p-6 sm:p-8 rounded-3xl max-w-md w-full border-2 border-purple-500/40 shadow-glow-purple relative">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 to-pink-600 flex items-center justify-center text-white shadow-lg">
                <Send className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">Submit UI/UX Battle?</h3>
                <span className="text-xs font-mono text-purple-300">SPARKLE '26 – Round 1</span>
              </div>
            </div>

            <p className="text-sm text-slate-300 leading-relaxed">
              Are you sure you want to finalize and lock your answers for Round 1? You will not be able to change them once submitted.
            </p>

            {/* Quick summary grid */}
            <div className="grid grid-cols-2 gap-3 my-5">
              <div className="bg-slate-900/90 border border-purple-500/20 p-3 rounded-xl text-center">
                <span className="block text-2xl font-bold text-emerald-400 font-mono">
                  {answeredCount}
                </span>
                <span className="text-xs text-slate-400">Questions Answered</span>
              </div>

              <div className="bg-slate-900/90 border border-purple-500/20 p-3 rounded-xl text-center">
                <span className="block text-2xl font-bold text-pink-400 font-mono">
                  {unansweredCount}
                </span>
                <span className="text-xs text-slate-400">Unanswered</span>
              </div>
            </div>

            {unansweredCount > 0 && (
              <div className="p-3 bg-amber-950/40 border border-amber-500/30 rounded-xl text-xs text-amber-300 flex items-start gap-2 mb-5">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
                <span>
                  Notice: You have {unansweredCount} unanswered {unansweredCount === 1 ? 'question' : 'questions'}. 
                  Unanswered questions will receive 0 marks.
                </span>
              </div>
            )}

            {/* Modal actions */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setShowSubmitModal(false)}
                className="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-700 transition"
              >
                Return to Quiz
              </button>
              <button
                onClick={handleConfirmSubmit}
                className="px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold text-white transition shadow-lg shadow-purple-900/40"
                style={{
                  background: 'linear-gradient(135deg, #8b5cf6 0%, #ec4899 100%)'
                }}
              >
                Confirm & Submit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
