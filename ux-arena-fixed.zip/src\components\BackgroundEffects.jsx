import React from 'react';

export default function BackgroundEffects() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {/* Dynamic ambient gradient orbs */}
      <div 
        className="absolute top-[-10%] left-[15%] w-[500px] h-[500px] rounded-full blur-[140px] opacity-25 animate-pulse-glow"
        style={{ background: 'radial-gradient(circle, #8b5cf6 0%, transparent 70%)' }}
      />
      <div 
        className="absolute bottom-[-10%] right-[10%] w-[550px] h-[550px] rounded-full blur-[150px] opacity-20 animate-pulse-glow"
        style={{ background: 'radial-gradient(circle, #3b82f6 0%, transparent 70%)', animationDelay: '1.5s' }}
      />
      <div 
        className="absolute top-[40%] right-[5%] w-[400px] h-[400px] rounded-full blur-[130px] opacity-20 animate-pulse-glow"
        style={{ background: 'radial-gradient(circle, #ec4899 0%, transparent 70%)', animationDelay: '3s' }}
      />
      <div 
        className="absolute bottom-[20%] left-[5%] w-[450px] h-[450px] rounded-full blur-[140px] opacity-15"
        style={{ background: 'radial-gradient(circle, #06b6d4 0%, transparent 70%)' }}
      />

      {/* Cyber Grid pattern */}
      <div className="absolute inset-0 cyber-grid opacity-30" />

      {/* Subtle Floating Geometric Shapes */}
      {/* Floating Diamond */}
      <div 
        className="absolute top-[18%] left-[8%] w-16 h-16 border border-purple-500/20 rounded-xl transform rotate-45 animate-float hidden md:block"
        style={{ animationDuration: '9s' }}
      >
        <div className="w-full h-full bg-purple-500/5 backdrop-blur-sm rounded-xl" />
      </div>

      {/* Floating Hexagon / Cube wireframe */}
      <div 
        className="absolute top-[65%] left-[12%] w-20 h-20 border border-blue-400/20 rounded-2xl transform rotate-12 animate-float-reverse hidden md:block"
        style={{ animationDuration: '12s' }}
      >
        <div className="w-8 h-8 border border-cyan-400/30 m-auto mt-5 rounded-lg" />
      </div>

      {/* Floating Ring Pink */}
      <div 
        className="absolute top-[22%] right-[12%] w-24 h-24 border-2 border-dashed border-pink-500/20 rounded-full animate-float hidden md:block"
        style={{ animationDuration: '14s' }}
      />

      {/* Floating Geometric Cross */}
      <div 
        className="absolute top-[75%] right-[15%] w-12 h-12 flex items-center justify-center animate-float-reverse hidden md:block"
        style={{ animationDuration: '11s' }}
      >
        <div className="w-10 h-1 bg-gradient-to-r from-purple-500/30 to-pink-500/30 rounded-full" />
        <div className="w-1 h-10 bg-gradient-to-b from-purple-500/30 to-pink-500/30 rounded-full absolute" />
      </div>

      {/* Subtle Scanlines overlay */}
      <div 
        className="absolute inset-0 opacity-[0.015] pointer-events-none"
        style={{
          backgroundImage: 'linear-gradient(rgba(255, 255, 255, 0) 50%, rgba(0, 0, 0, 0.5) 50%)',
          backgroundSize: '100% 4px'
        }}
      />
    </div>
  );
}
