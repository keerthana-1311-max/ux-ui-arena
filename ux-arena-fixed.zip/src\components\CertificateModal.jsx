import React, { useRef } from 'react';
import { Sparkles, Award, CheckCircle, Printer, X, Download } from 'lucide-react';

export default function CertificateModal({ isOpen, onClose, participant, score, totalMarks, percentage, tier }) {
  const certRef = useRef();

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-lg animate-fadeIn overflow-y-auto">
      <div className="w-full max-w-3xl flex flex-col items-center">
        {/* Certificate Card Printable Container */}
        <div 
          ref={certRef}
          className="w-full bg-[#0d0f22] border-4 border-[#8b5cf6]/50 rounded-3xl p-6 sm:p-10 relative overflow-hidden shadow-[0_0_50px_rgba(139,92,246,0.3)] text-center print:border-black print:text-black print:bg-white"
        >
          {/* Subtle Cyber Glow background inside certificate */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-pink-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

          {/* Golden/Purple double border */}
          <div className="border border-purple-500/30 rounded-2xl p-6 sm:p-8">
            {/* Fest Branding */}
            <div className="flex items-center justify-center gap-2 mb-2">
              <Sparkles className="w-5 h-5 text-pink-400" />
              <span className="font-mono text-xs sm:text-sm font-bold tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 uppercase">
                SPARKLE '26 • COLLEGE TECHNICAL FEST
              </span>
              <Sparkles className="w-5 h-5 text-blue-400" />
            </div>

            <h2 className="text-2xl sm:text-4xl font-extrabold text-white font-display tracking-wide uppercase mt-1">
              UX ARENA : UI/UX BATTLE
            </h2>
            <p className="text-xs sm:text-sm font-mono text-purple-300 mt-1 uppercase tracking-wider">
              Certificate of Performance – Round 1
            </p>

            <div className="my-6">
              <p className="text-xs text-slate-400 uppercase tracking-widest font-mono">This is proudly awarded to</p>
              <h3 className="text-2xl sm:text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-pink-400 via-purple-300 to-cyan-300 mt-1 tracking-tight">
                {participant.name || 'UX Contender'}
              </h3>
              <p className="text-sm font-semibold text-slate-300 mt-0.5">
                {participant.college || 'Department of Design & Technology'}
              </p>
            </div>

            <p className="text-xs sm:text-sm text-slate-300 max-w-lg mx-auto leading-relaxed">
              for actively decoding digital interfaces, evaluating usability heuristics, and demonstrating exemplary design proficiency in Round 1 of the UX Battle.
            </p>

            {/* Score & Rank Badges */}
            <div className="my-6 grid grid-cols-3 gap-3 max-w-md mx-auto">
              <div className="p-3 bg-purple-950/40 border border-purple-500/30 rounded-xl">
                <span className="block text-xs text-slate-400 font-mono">Total Score</span>
                <span className="text-xl sm:text-2xl font-bold text-white font-mono">{score} / {totalMarks}</span>
              </div>
              <div className="p-3 bg-pink-950/40 border border-pink-500/30 rounded-xl">
                <span className="block text-xs text-slate-400 font-mono">Percentage</span>
                <span className="text-xl sm:text-2xl font-bold text-pink-400 font-mono">{percentage}%</span>
              </div>
              <div className="p-3 bg-blue-950/40 border border-blue-500/30 rounded-xl">
                <span className="block text-xs text-slate-400 font-mono">Design Rank</span>
                <span className="text-sm sm:text-base font-bold text-cyan-300 font-mono">{tier.title.split(' ')[1] || 'CHAMPION'}</span>
              </div>
            </div>

            {/* Verification Signatures / Watermark */}
            <div className="pt-6 border-t border-purple-500/20 flex items-center justify-between text-xs text-slate-400 font-mono">
              <div className="text-left">
                <p className="text-white font-semibold">Jury Committee</p>
                <p className="text-[10px]">SPARKLE '26 Technical Guild</p>
              </div>

              <div className="w-12 h-12 rounded-full border border-purple-400/40 flex items-center justify-center bg-purple-500/10 text-purple-300">
                <Award className="w-6 h-6" />
              </div>

              <div className="text-right">
                <p className="text-white font-semibold">Round 1 Verified</p>
                <p className="text-[10px]">Date: 2026-11-20</p>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="flex items-center justify-center gap-3 mt-6 print:hidden">
          <button
            onClick={handlePrint}
            className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs sm:text-sm uppercase tracking-wider flex items-center gap-2 transition shadow-lg shadow-purple-900/50"
          >
            <Printer className="w-4 h-4" />
            <span>Print / Save as PDF</span>
          </button>
          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 font-semibold text-xs sm:text-sm uppercase tracking-wider transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
