import React from 'react';
import { Sparkles, Clock, Volume2, VolumeX, Maximize2, Minimize2, Award, Zap } from 'lucide-react';
import { sound } from '../utils/sound';

export default function Navbar({
  currentQuestionIndex,
  totalQuestions,
  currentSection,
  marks,
  timeLeft,
  soundEnabled,
  onToggleSound,
  isFullscreen,
  onToggleFullscreen,
  isQuizActive = true
}) {
  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const isWarning = timeLeft <= 60 && timeLeft > 0;
  const progressRatio = Math.min(100, Math.max(0, (timeLeft / 600) * 100));

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-xl bg-[#080914]/85 border-b border-purple-500/20 px-4 sm:px-8 py-3 transition-all duration-300">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Brand Identity */}
        <div className="flex items-center gap-3">
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 rounded-xl blur opacity-75 group-hover:opacity-100 transition duration-300 animate-pulse" />
            <div className="relative w-10 h-10 rounded-xl bg-slate-900 border border-purple-400/50 flex items-center justify-center text-purple-300">
              <Sparkles className="w-5 h-5 text-purple-400" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-sm sm:text-base tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400">
                SPARKLE '26
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-purple-950/70 border border-purple-500/40 text-purple-300 hidden sm:inline-block">
                TECH FEST
              </span>
            </div>
            <div className="text-[11px] font-mono text-slate-400 flex items-center gap-1.5">
              <span className="text-white font-semibold">UX ARENA</span>
              <span>•</span>
              <span className="text-pink-400">ROUND 1</span>
            </div>
          </div>
        </div>

        {/* Center Section & Question Badge (Only during active quiz) */}
        {isQuizActive && (
          <div className="hidden md:flex items-center gap-3">
            <div className="flex items-center gap-1.5 bg-slate-900/90 border border-purple-500/30 px-3.5 py-1.5 rounded-full shadow-inner">
              <Award className="w-4 h-4 text-purple-400" />
              <span className="text-xs font-semibold text-slate-200">
                {currentSection === 'A' ? 'Section A: Decode' : 'Section B: Visual UI/UX'}
              </span>
              <span className="text-[10px] font-mono bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded-full border border-purple-500/30">
                +{marks} {marks === 1 ? 'Mark' : 'Marks'}
              </span>
            </div>

            <div className="text-xs font-mono text-slate-300 bg-slate-900/60 border border-slate-800 px-3 py-1.5 rounded-full">
              Q <span className="text-purple-400 font-bold">{currentQuestionIndex + 1}</span> / {totalQuestions}
            </div>
          </div>
        )}

        {/* Right Controls: Timer + Sound + Fullscreen */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Countdown Timer */}
          {isQuizActive && (
            <div className={`relative flex items-center gap-2 px-3 sm:px-4 py-1.5 rounded-xl border transition-all duration-300 ${
              isWarning 
                ? 'bg-red-950/60 border-red-500 animate-timer-warning text-red-200' 
                : 'bg-slate-900/90 border-purple-500/30 text-slate-200 shadow-glow-purple'
            }`}>
              <div className="relative w-5 h-5 flex items-center justify-center">
                {/* Mini SVG circular indicator */}
                <svg className="w-5 h-5 -rotate-90" viewBox="0 0 36 36">
                  <path
                    className="text-slate-800"
                    strokeWidth="3"
                    stroke="currentColor"
                    fill="none"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                  <path
                    className={isWarning ? "text-red-500 transition-all duration-1000" : "text-purple-400 transition-all duration-1000"}
                    strokeDasharray={`${progressRatio}, 100`}
                    strokeWidth="3.5"
                    strokeLinecap="round"
                    stroke="currentColor"
                    fill="none"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                </svg>
                <Clock className={`w-2.5 h-2.5 absolute ${isWarning ? 'text-red-400' : 'text-purple-400'}`} />
              </div>
              <div className="flex flex-col">
                <span className={`font-mono font-bold text-xs sm:text-sm tracking-wider ${isWarning ? 'text-red-400 animate-pulse' : 'text-slate-100'}`}>
                  {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
                </span>
              </div>
            </div>
          )}

          {/* Audio toggle button */}
          <button
            onClick={onToggleSound}
            className="p-2 rounded-xl bg-slate-900/80 border border-slate-700/80 hover:border-purple-400 text-slate-300 hover:text-purple-300 transition-all shadow-sm"
            title={soundEnabled ? "Mute UI Sound" : "Enable UI Sound"}
            aria-label="Sound Toggle"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-purple-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>

          {/* Fullscreen toggle (Ideal for projector & auditorium displays) */}
          <button
            onClick={onToggleFullscreen}
            className="hidden sm:flex p-2 rounded-xl bg-slate-900/80 border border-slate-700/80 hover:border-purple-400 text-slate-300 hover:text-purple-300 transition-all shadow-sm"
            title={isFullscreen ? "Exit Fullscreen" : "Projector / Fullscreen Mode"}
            aria-label="Fullscreen Toggle"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </header>
  );
}
