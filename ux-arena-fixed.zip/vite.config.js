import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  build: {
    chunkSizeWarningLimit: 900,
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom'],
          relay: ['peerjs'],
          supabase: ['@supabase/supabase-js'],
          icons: ['lucide-react', 'qrcode.react', 'canvas-confetti'],
        },
      },
    },
  },
});
