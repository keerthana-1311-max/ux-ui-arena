# SPARKLE '26 – UX ARENA LIVE QUIZ PLATFORM

Production-ready, real-time live quiz platform built for college technical fests and live auditorium competitions.

Features a dual-mode experience:
1. **Coordinator Command Center** – Real-time host controls (Start, Next, Prev, Lock, Pause, Resume, End, Preview & Publish Results, Reset, Configurable Timer).
2. **Participant Arena** – Cross-device live participant view with synchronized question releases, server-authoritative timers, instantaneous answer locking, floating reactions, and full-screen celebration scoreboard.

---

## Architecture & Technology Stack

- **Frontend**: React 18, Vite 5, Tailwind CSS, Lucide Icons, Canvas Confetti, QRCode.react.
- **Backend & Database**: Supabase (PostgreSQL with Row Level Security, Realtime CDC replication, Auth, RPC functions).
- **Audio & Animations**: Web Audio API synthesized tones, CSS keyframe glow & floating animations.
- **Hosting & Deployment**: Netlify with SPA redirects and security headers.

---

## 1. Quick Start (Local Development)

```bash
# 1. Install dependencies
npm install

# 2. Copy environment template
cp .env.example .env

# 3. Add your Supabase credentials into .env:
# VITE_SUPABASE_URL=https://your-project.supabase.co
# VITE_SUPABASE_ANON_KEY=your-anon-public-key

# 4. Start local development server
npm run dev

# 5. Build for production
npm run build
```

---

## 2. Supabase Setup Guide (One-Time Setup)

### Step 1: Create Supabase Project
1. Go to [supabase.com](https://supabase.com) and create a new project (e.g. `sparkle26-ux-arena`).
2. Copy your **Project URL** and **anon public key** from **Project Settings > API**.

### Step 2: Run Database Schema SQL
1. In your Supabase dashboard, open the **SQL Editor** from the left navigation.
2. Open the file [`supabase/schema.sql`](file:///C:/Users/Niruthanya%20S/.gemini/antigravity/scratch/ux-arena/supabase/schema.sql) in this repository.
3. Paste the entire SQL script into the Supabase SQL Editor and click **Run**.
4. This script automatically:
   - Creates the `quiz_sessions`, `quiz_participants`, `quiz_questions`, `quiz_answers`, and `quiz_results` tables.
   - Populates the 10 official SPARKLE '26 questions and protected answer keys.
   - Enforces strict **Row Level Security (RLS)** protecting answers and coordinator actions.
   - Creates the `submit_answer`, `publish_quiz_results`, and `reset_quiz_session` secure PostgreSQL functions.
   - Enables **Supabase Realtime** publication on all tables for instant push sync.

### Step 3: Create Coordinator User
1. In Supabase dashboard, go to **Authentication > Users**.
2. Click **Add User** > **Create User**.
3. Enter:
   - Email: `coordinator@sparkle2026.com` (or your preferred coordinator email)
   - Password: your secure event passkey (e.g. `Sparkle@2026!`)
   - Auto Confirm User: **Checked** (Enabled)
4. Click **Create User**.
*(Alternatively, you can click "Need to create the initial coordinator account? Sign Up" directly from the Coordinator Login modal inside the app).*

---

## 3. Netlify Deployment Guide

1. Push this repository to GitHub or GitLab.
2. In Netlify, click **Add new site** > **Import an existing project**.
3. Build Settings:
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`
4. Environment Variables in Netlify (**Site configuration > Environment variables**):
   - `VITE_SUPABASE_URL` = `https://your-project.supabase.co`
   - `VITE_SUPABASE_ANON_KEY` = `your-supabase-anon-key`
5. Click **Deploy site**.
6. Netlify will generate your public URL (e.g., `https://sparkle-ux-arena.netlify.app`).

---

## 4. Event Day Checklist (For Fest Coordinators)

- [ ] **Projector Setup**: Open the site on the auditorium laptop, sign in as Coordinator, and test the **"Projector Mode"** on the scoreboard tab.
- [ ] **Lobby Projection**: Before starting, project the **QR Code Modal** on the auditorium screen so participants can scan and check in with their mobile phones.
- [ ] **Room PIN**: Default Room PIN is `UX2026` (displayed on the dashboard and QR code).
- [ ] **Registration**: Keep Registration **OPEN** while contestants take their seats. Click **"Registration: CLOSED"** when Round 1 begins to lock out latecomers.
- [ ] **Question Flow**:
  - Click **START QUIZ (RELEASE Q1)** to launch Question 1 simultaneously for all devices.
  - The synchronized timer counts down from 20s (or your configured duration).
  - Click **PAUSE QUIZ** if an announcement needs to be made; click **RESUME QUIZ** to continue with exact remaining time.
  - Answers lock automatically when timer expires, or immediately when clicking **LOCK ANSWERS NOW**.
  - Click **NEXT QUESTION** to advance all connected devices.
- [ ] **End & Publish Results**:
  - When all 10 questions are finished, click **END QUIZ**.
  - Click **PREVIEW RESULTS** to inspect the confidential computed leaderboard and top 3 podium.
  - When ready to announce the winners to the crowd, click **PUBLISH RESULTS TO PARTICIPANTS**.
  - All participant devices and the auditorium projector will instantly display the final ranked scoreboard with gold/silver/bronze badges, accuracy breakdown, and victory confetti!
- [ ] **Export Records**: Click **Export CSV** on the scoreboard to download the official Excel/CSV record for certificates and records.
