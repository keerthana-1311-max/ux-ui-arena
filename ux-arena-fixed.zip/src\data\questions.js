const A = 'Section A – Decode the Design';
const B = 'Section B – Visual UI/UX Challenge';
const o = (...t) => t.map((text, i) => ({ id: 'ABCD'[i], text }));
export const QUIZ_METADATA = { title: 'UX ARENA', totalQuestions: 10, totalMarks: 15, durationSeconds: 600 };
export const QUESTIONS = [
  { id: 1, section: 'A', sectionTitle: A, marks: 1, type: 'emoji-decode', question: 'Decode the emoji: 🎨 + 🖥️ + ✏️ — which field does this combination describe?',
    options: o('UI/UX Design', 'Print Publishing', 'Video Editing', 'Game Development'), correctAnswer: 'A',
    explanation: 'Visual art (🎨), a digital screen (🖥️) and precise drafting (✏️) together describe UI/UX design: crafting visual, screen-based experiences with deliberate structure.' },
  { id: 2, section: 'A', sectionTitle: A, marks: 1, type: 'tool-logos', question: 'Which two design tools are shown?',
    options: o('Sketch and Photoshop', 'Figma and Canva', 'XD and Illustrator', 'Framer and Penpot'), correctAnswer: 'B',
    explanation: 'The multicolour five-circle mark is Figma (collaborative interface design); the gradient script mark is Canva (template-driven graphics).' },
  { id: 3, section: 'A', sectionTitle: A, marks: 1, type: 'user-journey', question: 'What user journey does this flow represent?',
    steps: [{ icon: '👤', label: 'User', desc: 'Arrives' }, { icon: '📝', label: 'Sign Up', desc: 'Creates account' }, { icon: '🔐', label: 'Login', desc: 'Authenticates' }, { icon: '✅', label: 'Success', desc: 'Reaches goal' }],
    options: o('Checkout funnel', 'Onboarding and authentication flow', 'Bug-reporting flow', 'Content publishing flow'), correctAnswer: 'B',
    explanation: 'Visitor → sign up → log in → success is an onboarding and authentication journey. Mapping such flows exposes friction points.' },
  { id: 4, section: 'A', sectionTitle: A, marks: 1, type: 'icon-detective', question: 'Which icon is the universal symbol for notifications?',
    options: o('Magnifying glass', 'Shopping cart', 'Bell', 'Gear'), correctAnswer: 'C',
    explanation: 'The bell is the established notification metaphor. Following conventions supports "Consistency and standards" (Nielsen heuristic).' },
  { id: 5, section: 'A', sectionTitle: A, marks: 1, type: 'responsive-design', question: 'A layout reflows from 3 columns (desktop) to 1 stacked column (mobile). What is this called?',
    options: o('Adaptive caching', 'Responsive design', 'Skeuomorphism', 'Progressive disclosure'), correctAnswer: 'B',
    explanation: 'Responsive design uses fluid grids and breakpoints so content reflows to fit any screen size.' },
  { id: 6, section: 'B', sectionTitle: B, marks: 2, type: 'ecommerce-mockup', question: 'Which element on this product page builds buyer trust through social proof?',
    options: o('Star rating with review count', 'The search bar', 'The browser URL', 'The cart icon'), correctAnswer: 'A',
    explanation: 'Ratings with review counts (4.9 from 1,420 reviews) are social proof, a proven e-commerce pattern that reduces purchase uncertainty.' },
  { id: 7, section: 'B', sectionTitle: B, marks: 2, type: 'design-comparison', question: 'Compare Design A and Design B. Which login screen has better usability?',
    options: o('Design A: compact and minimal', 'Design B: clear labels, spacing and hierarchy', 'Both are equal', 'Neither, a login should use a modal'), correctAnswer: 'B',
    explanation: 'Design B has clear labels, readable text, correct spelling and visible hierarchy. Design A has typos, cramped targets and unclear affordances, violating "Aesthetic and minimalist design" and "Recognition rather than recall".' },
  { id: 8, section: 'B', sectionTitle: B, marks: 2, type: 'breadcrumb-nav', question: 'Home > Products > Mobiles is which navigation pattern?',
    options: o('Tab bar', 'Pagination', 'Breadcrumb navigation', 'Mega menu'), correctAnswer: 'C',
    explanation: 'Breadcrumbs show the hierarchical location trail, supporting "Visibility of system status" and easy backtracking.' },
  { id: 9, section: 'B', sectionTitle: B, marks: 2, type: 'confirmation-modal', question: 'A dialog asks "Permanently Delete File?" before deleting. Which usability heuristic is this?',
    options: o('Aesthetic design', 'Flexibility and efficiency', 'Error prevention', 'Help and documentation'), correctAnswer: 'C',
    explanation: 'Confirming destructive actions is Error Prevention: it stops costly mistakes before they happen.' },
  { id: 10, section: 'B', sectionTitle: B, marks: 2, type: 'hamburger-menu', question: 'What does the highlighted three-line icon in the header represent?',
    options: o('Settings panel', 'Download', 'Navigation menu (hamburger)', 'Text alignment'), correctAnswer: 'C',
    explanation: 'The hamburger icon collapses primary navigation into a menu, saving space on small screens.' },
];

// Sanitized question set for public participant views (strips secret answer keys & explanations)
export const PUBLIC_QUESTIONS = QUESTIONS.map(({ correctAnswer, explanation, ...rest }) => rest);

