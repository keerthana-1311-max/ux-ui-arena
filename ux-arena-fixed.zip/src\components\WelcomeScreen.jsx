import React, { useState } from 'react';
import { 
  Sparkles, 
  Play, 
  Clock, 
  Award, 
  CheckCircle2, 
  ShieldAlert, 
  Layers, 
  Flame, 
  Eye, 
  ArrowRight,
  Terminal,
  Cpu
} from 'lucide-react';
import { QUIZ_METADATA } from '../data/questions';
import { sound } from '../utils/sound';

export default function WelcomeScreen({ onStartQuiz, participantName, setParticipantName }) {
  const [collegeName, setCollegeName] = useState('');

  const handleStart = () => {
    sound.playNext();
    onStartQuiz({
      name: participantName.trim() || 'Contender',
      college: collegeName.trim() || 'Design Guild'
    });
  };

  return (
    <div className="relative z-10 max-w-5xl mx-auto px-4 py-8 sm:py-12 flex flex-col items-center justify-center min-h-[calc(100vh-80px)]">
      {/* Top Event Badge */}
      <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-gradient-to-r from-purple-500/10 via-pink-500/10 to-blue-500/10 border border-purple-500/30 text-purple-300 text-xs sm:text-sm font-mono uppercase tracking-widest mb-6 animate-pulse">
        <Sparkles className="w-4 h-4 text-pink-400" />
        <span>SPARKLE '26 • COLLEGE TECHNICAL FEST</span>
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
        <span className="text-emerald-400 font-semibold">ROUND 1 LIVE</span>
      </div>

      {/* Hero Title Section */}
      <div className="text-center space-y-3 max-w-3xl">
        <h1 className="text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-tight font-display">
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 filter drop-shadow-[0_0_35px_rgba(168,85,247,0.35)]">
            UX ARENA
          </span>
        </h1>

        <div className="flex items-center justify-center gap-3">
          <div className="h-px w-8 sm:w-16 bg-gradient-to-r from-transparent to-pink-500" />
          <p className="text-lg sm:text-2xl font-bold tracking-widest text-slate-200 uppercase font-mono">
            UI/UX BATTLE – ROUND 1
          </p>
          <div className="h-px w-8 sm:w-16 bg-gradient-to-l from-transparent to-pink-500" />
        </div>

        <p className="text-xl sm:text-2xl font-semibold text-transparent bg-clip-text bg-gradient-to-r from-pink-400 via-purple-300 to-cyan-400 font-mono italic">
          "Think. Design. Decode. Dominate."
        </p>

        <p className="text-sm sm:text-base text-slate-400 max-w-2xl mx-auto leading-relaxed pt-2">
          Step inside the digital proving ground. Decode emoji visual metaphors, analyze product journeys, 
          dissect real-world UI patterns, and apply Nielsen's usability heuristics under pressure.
        </p>
      </div>

      {/* Battle Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 w-full max-w-4xl mt-8">
        <div className="glass-panel p-4 rounded-2xl flex flex-col items-center text-center border-purple-500/20 hover:border-purple-500/40 transition-all">
          <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center text-purple-400 mb-2">
            <Layers className="w-5 h-5" />
          </div>
          <span className="text-2xl sm:text-3xl font-extrabold text-white font-mono">10</span>
          <span className="text-xs text-slate-400 font-semibold mt-0.5">Total Questions</span>
        </div>

        <div className="glass-panel p-4 rounded-2xl flex flex-col items-center text-center border-pink-500/20 hover:border-pink-500/40 transition-all">
          <div className="w-10 h-10 rounded-xl bg-pink-500/10 flex items-center justify-center text-pink-400 mb-2">
            <Award className="w-5 h-5" />
          </div>
          <span className="text-2xl sm:text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-purple-400 font-mono">15</span>
          <span className="text-xs text-slate-400 font-semibold mt-0.5">Total Marks</span>
        </div>

        <div className="glass-panel p-4 rounded-2xl flex flex-col items-center text-center border-cyan-500/20 hover:border-cyan-500/40 transition-all">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center text-cyan-400 mb-2">
            <Clock className="w-5 h-5" />
          </div>
          <span className="text-2xl sm:text-3xl font-extrabold text-cyan-400 font-mono">10:00</span>
          <span className="text-xs text-slate-400 font-semibold mt-0.5">Countdown Timer</span>
        </div>

        <div className="glass-panel p-4 rounded-2xl flex flex-col items-center text-center border-blue-500/20 hover:border-blue-500/40 transition-all">
          <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-400 mb-2">
            <Flame className="w-5 h-5" />
          </div>
          <span className="text-2xl sm:text-3xl font-extrabold text-blue-400 font-mono">2</span>
          <span className="text-xs text-slate-400 font-semibold mt-0.5">Battle Sections</span>
        </div>
      </div>

      {/* Quiz Structure Breakdown */}
      <div className="w-full max-w-4xl mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Section A Card */}
        <div className="glass-panel p-5 rounded-2xl border-purple-500/30 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono font-bold text-purple-400 bg-purple-950/70 border border-purple-500/30 px-2.5 py-1 rounded-lg">
                SECTION A
              </span>
              <span className="text-xs font-mono text-purple-300 font-bold">5 Questions × 1 Mark = 5 Marks</span>
            </div>
            <h3 className="text-base font-bold text-white mt-1">Decode the Design</h3>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Test your visual decoding agility: emoji UI combinations, industry design tools, user journey funnels, and responsive metaphors.
            </p>
          </div>
          <div className="mt-3 pt-3 border-t border-purple-500/20 flex items-center gap-2 text-[11px] text-purple-300 font-mono">
            <span>🎨 Emoji Decode</span>
            <span>•</span>
            <span>📱 Responsive</span>
            <span>•</span>
            <span>🔍 Metaphors</span>
          </div>
        </div>

        {/* Section B Card */}
        <div className="glass-panel p-5 rounded-2xl border-pink-500/30 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono font-bold text-pink-400 bg-pink-950/70 border border-pink-500/30 px-2.5 py-1 rounded-lg">
                SECTION B
              </span>
              <span className="text-xs font-mono text-pink-300 font-bold">5 Questions × 2 Marks = 10 Marks</span>
            </div>
            <h3 className="text-base font-bold text-white mt-1">Visual UI/UX Challenge</h3>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              High-stakes visual evaluation: identify authentic e-commerce patterns, evaluate Design A vs Design B heuristics, navigation hierarchy, and destructive error prevention.
            </p>
          </div>
          <div className="mt-3 pt-3 border-t border-pink-500/20 flex items-center gap-2 text-[11px] text-pink-300 font-mono">
            <span>🛒 Live Mockup</span>
            <span>•</span>
            <span>⚖️ A/B Usability</span>
            <span>•</span>
            <span>🛡️ Heuristics</span>
          </div>
        </div>
      </div>

      {/* Participant Info Entry & Rules Card */}
      <div className="w-full max-w-xl mt-6 glass-panel p-5 sm:p-6 rounded-2xl border-purple-500/30 shadow-glow-purple">
        <div className="flex items-center gap-2 mb-4 text-purple-300 font-bold text-sm">
          <Terminal className="w-4 h-4 text-pink-400" />
          <span>PARTICIPANT REGISTRATION & ARENA RULES</span>
        </div>

        <div className="space-y-3">
          <div>
            <label className="block text-xs font-mono text-slate-300 mb-1">
              Contender Name / Handle:
            </label>
            <input
              type="text"
              value={participantName}
              onChange={(e) => setParticipantName(e.target.value)}
              placeholder="e.g. Alex Mercer (or Team Neon)"
              className="w-full bg-slate-900/90 border border-purple-500/40 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400 transition"
              maxLength={40}
            />
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-300 mb-1">
              College / Institution:
            </label>
            <input
              type="text"
              value={collegeName}
              onChange={(e) => setCollegeName(e.target.value)}
              placeholder="e.g. Department of Design & Tech"
              className="w-full bg-slate-900/90 border border-purple-500/40 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400 transition"
              maxLength={60}
            />
          </div>
        </div>

        {/* Quick Rules Check */}
        <div className="mt-4 pt-4 border-t border-slate-800 text-xs text-slate-300 space-y-1.5 font-sans">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>Single question displayed at a time with instant option feedback</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>Keyboard shortcuts enabled: Press [A, B, C, D] to select options</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>10-minute master timer with auto-submit upon expiration</span>
          </div>
        </div>

        {/* Start Button */}
        <button
          onClick={handleStart}
          className="w-full mt-6 py-4 px-6 rounded-xl font-display font-bold text-base sm:text-lg text-white tracking-wider uppercase transition-all duration-300 flex items-center justify-center gap-3 relative overflow-hidden group shadow-lg shadow-purple-900/50 hover:shadow-glow-purple active:scale-[0.99]"
          style={{
            background: 'linear-gradient(135deg, #8b5cf6 0%, #ec4899 50%, #3b82f6 100%)'
          }}
        >
          <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
          <Play className="w-5 h-5 fill-white" />
          <span>ENTER UX ARENA • START QUIZ</span>
          <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>

      {/* Footer Meta */}
      <div className="mt-8 text-center text-xs text-slate-500 font-mono">
        SPARKLE '26 Technical Symposium • UI/UX Track • Organised for Innovators & Designers
      </div>
    </div>
  );
}
