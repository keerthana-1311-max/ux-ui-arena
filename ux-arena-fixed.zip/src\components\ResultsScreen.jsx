import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { 
  Sparkles, 
  Award, 
  CheckCircle2, 
  XCircle, 
  RotateCcw, 
  BookOpen, 
  Share2, 
  Download, 
  TrendingUp, 
  Layers, 
  Clock, 
  Check, 
  ChevronRight,
  Flame
} from 'lucide-react';
import ReviewModal from './ReviewModal';
import CertificateModal from './CertificateModal';
import { sound } from '../utils/sound';

export default function ResultsScreen({
  questions,
  answers,
  timeTakenSeconds,
  participant,
  onRestartQuiz
}) {
  const [displayScore, setDisplayScore] = useState(0);
  const [showReview, setShowReview] = useState(false);
  const [showCert, setShowCert] = useState(false);
  const [copiedShare, setCopiedShare] = useState(false);

  // Compute marks & counts
  let correctCount = 0;
  let incorrectCount = 0;
  let scoreA = 0; // Section A: 1 mark each
  let scoreB = 0; // Section B: 2 marks each

  questions.forEach((q) => {
    const isCorrect = answers[q.id] === q.correctAnswer;
    if (isCorrect) {
      correctCount += 1;
      if (q.section === 'A') scoreA += q.marks;
      if (q.section === 'B') scoreB += q.marks;
    } else {
      incorrectCount += 1;
    }
  });

  const totalScore = scoreA + scoreB;
  const maxScore = 15;
  const percentage = Math.round((totalScore / maxScore) * 100);

  // Performance tier computation
  const getTier = () => {
    if (totalScore >= 14) {
      return {
        title: "🌟 UX GRANDMASTER",
        message: "Phenomenal mastery! You have exceptional design heuristics intuition, flawless visual awareness, and top-tier product sense.",
        color: "from-purple-400 via-pink-400 to-amber-300",
        badgeBg: "bg-purple-950/80 border-purple-400 text-purple-200"
      };
    } else if (totalScore >= 11) {
      return {
        title: "⚡ UI CHAMPION",
        message: "Outstanding performance! Your visual analysis and interface problem-solving skills are among the very best in the arena.",
        color: "from-blue-400 via-purple-400 to-pink-400",
        badgeBg: "bg-blue-950/80 border-blue-400 text-blue-200"
      };
    } else if (totalScore >= 8) {
      return {
        title: "🎨 DESIGN PRACTITIONER",
        message: "Solid design fundamentals! You decoded the key visual concepts with great promise. Fine-tune your heuristics for Round 2.",
        color: "from-cyan-400 to-emerald-400",
        badgeBg: "bg-emerald-950/80 border-emerald-400 text-emerald-200"
      };
    } else {
      return {
        title: "🚀 UX APPRENTICE",
        message: "Valiant effort in the Battle! Keep sharpening your Nielsen usability heuristics, micro-interactions, and design systems.",
        color: "from-amber-400 to-orange-400",
        badgeBg: "bg-amber-950/80 border-amber-400 text-amber-200"
      };
    }
  };

  const tier = getTier();

  // Trigger celebration confetti and animated score counter
  useEffect(() => {
    sound.playVictory();

    // Confetti burst
    if (percentage >= 50) {
      const count = 200;
      const defaults = {
        origin: { y: 0.6 }
      };

      const fire = (particleRatio, opts) => {
        confetti({
          ...defaults,
          ...opts,
          particleCount: Math.floor(count * particleRatio)
        });
      };

      fire(0.25, { spread: 26, startVelocity: 55, colors: ['#8b5cf6', '#ec4899', '#3b82f6'] });
      fire(0.2, { spread: 60, colors: ['#06b6d4', '#a855f7', '#f43f5e'] });
      fire(0.35, { spread: 100, decay: 0.91, scalar: 0.8 });
      fire(0.1, { spread: 120, startVelocity: 25, decay: 0.92, scalar: 1.2 });
      fire(0.1, { spread: 120, startVelocity: 45 });
    }

    // Number counting animation
    let start = 0;
    const duration = 1200;
    const stepTime = Math.max(20, Math.floor(duration / (totalScore || 1)));

    const timer = setInterval(() => {
      start += 1;
      if (start >= totalScore) {
        setDisplayScore(totalScore);
        clearInterval(timer);
      } else {
        setDisplayScore(start);
      }
    }, stepTime);

    return () => clearInterval(timer);
  }, [totalScore, percentage]);

  const handleShare = () => {
    const text = `🏆 SPARKLE '26 – UX ARENA (UI/UX BATTLE – Round 1)\n` +
      `Contender: ${participant.name || 'Anonymous'}\n` +
      `Score: ${totalScore}/15 Marks (${percentage}%)\n` +
      `Rank: ${tier.title}\n` +
      `Section A: ${scoreA}/5 | Section B: ${scoreB}/10\n` +
      `Think. Design. Decode. Dominate. 🚀`;

    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 3000);
    }
  };

  const timeFormatted = `${Math.floor(timeTakenSeconds / 60)}m ${timeTakenSeconds % 60}s`;

  return (
    <div className="relative z-10 max-w-4xl mx-auto px-4 py-8 sm:py-12 flex flex-col items-center">
      {/* Event Header Banner */}
      <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-purple-950/80 border border-purple-500/30 text-purple-300 text-xs font-mono uppercase tracking-widest mb-4">
        <Sparkles className="w-4 h-4 text-pink-400" />
        <span>SPARKLE '26 • ROUND 1 BATTLE RESULTS</span>
      </div>

      <h1 className="text-3xl sm:text-5xl font-extrabold text-center font-display tracking-tight text-white">
        UX ARENA SCORECARD
      </h1>
      <p className="text-sm font-mono text-purple-300 mt-1">
        Contender: <span className="text-white font-bold">{participant.name}</span> ({participant.college})
      </p>

      {/* Main Scorecard Glass Panel */}
      <div className="w-full mt-8 glass-panel p-6 sm:p-10 rounded-3xl border-purple-500/30 shadow-2xl relative overflow-hidden">
        {/* Glow backdrop */}
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row items-center justify-between gap-8 pb-8 border-b border-purple-500/20">
          {/* Animated Circular Score Gauge */}
          <div className="relative flex items-center justify-center shrink-0">
            {/* Outer SVG radial progress */}
            <svg className="w-44 h-44 sm:w-52 sm:h-52 -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="42"
                className="text-slate-800"
                strokeWidth="7"
                stroke="currentColor"
                fill="none"
              />
              <circle
                cx="50"
                cy="50"
                r="42"
                strokeWidth="8"
                strokeDasharray={`${(percentage / 100) * 264}, 264`}
                strokeLinecap="round"
                fill="none"
                className="transition-all duration-1000 ease-out"
                stroke="url(#scoreGrad)"
              />
              <defs>
                <linearGradient id="scoreGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#8b5cf6" />
                  <stop offset="50%" stopColor="#ec4899" />
                  <stop offset="100%" stopColor="#06b6d4" />
                </linearGradient>
              </defs>
            </svg>

            {/* Inner Score Counter */}
            <div className="absolute flex flex-col items-center justify-center text-center">
              <span className="text-4xl sm:text-5xl font-extrabold text-white font-mono tracking-tight">
                {displayScore}
                <span className="text-xl sm:text-2xl text-slate-500 font-normal">/{maxScore}</span>
              </span>
              <span className="text-xs font-mono uppercase tracking-wider text-purple-300 font-semibold mt-1">
                Marks Obtained
              </span>
              <span className="text-xs font-bold text-pink-400 font-mono">
                {percentage}% Score
              </span>
            </div>
          </div>

          {/* Performance Tier & Message */}
          <div className="flex-1 flex flex-col items-center md:items-start text-center md:text-left">
            <div className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border text-xs sm:text-sm font-mono font-bold tracking-wide uppercase shadow-sm ${tier.badgeBg}`}>
              <Flame className="w-4 h-4 text-pink-400" />
              <span>{tier.title}</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-slate-300 mt-3 font-display">
              {percentage >= 80 ? "Superb Design Execution!" : percentage >= 50 ? "Solid Battle Showing!" : "Round 1 Completed!"}
            </h2>

            <p className="mt-2 text-sm sm:text-base text-slate-300 leading-relaxed max-w-lg">
              {tier.message}
            </p>

            <div className="mt-4 flex flex-wrap items-center gap-3 text-xs font-mono text-slate-400">
              <span className="flex items-center gap-1.5 bg-slate-900/80 px-3 py-1.5 rounded-xl border border-slate-800">
                <Clock className="w-3.5 h-3.5 text-purple-400" />
                <span>Time: {timeFormatted}</span>
              </span>
              <span className="flex items-center gap-1.5 bg-slate-900/80 px-3 py-1.5 rounded-xl border border-slate-800">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>{correctCount} Correct</span>
              </span>
              <span className="flex items-center gap-1.5 bg-slate-900/80 px-3 py-1.5 rounded-xl border border-slate-800">
                <XCircle className="w-3.5 h-3.5 text-red-400" />
                <span>{incorrectCount} Incorrect</span>
              </span>
            </div>
          </div>
        </div>

        {/* Section Score Breakdown Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-8">
          {/* Section A Card */}
          <div className="p-4 sm:p-5 rounded-2xl bg-slate-950/60 border border-purple-500/30 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-purple-400 uppercase tracking-wider">
                  SECTION A – DECODE THE DESIGN
                </span>
                <span className="text-xs font-mono text-slate-400">1 mark each</span>
              </div>
              <div className="flex items-baseline justify-between mt-3">
                <span className="text-3xl font-bold text-white font-mono">{scoreA} <span className="text-lg text-slate-500 font-normal">/ 5 Marks</span></span>
                <span className="text-sm font-mono text-purple-300 font-bold">{Math.round((scoreA / 5) * 100)}%</span>
              </div>
            </div>
            <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden mt-3 border border-slate-800">
              <div 
                className="bg-purple-500 h-full rounded-full transition-all duration-700"
                style={{ width: `${(scoreA / 5) * 100}%` }}
              />
            </div>
          </div>

          {/* Section B Card */}
          <div className="p-4 sm:p-5 rounded-2xl bg-slate-950/60 border border-pink-500/30 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-pink-400 uppercase tracking-wider">
                  SECTION B – VISUAL UI/UX CHALLENGE
                </span>
                <span className="text-xs font-mono text-slate-400">2 marks each</span>
              </div>
              <div className="flex items-baseline justify-between mt-3">
                <span className="text-3xl font-bold text-white font-mono">{scoreB} <span className="text-lg text-slate-500 font-normal">/ 10 Marks</span></span>
                <span className="text-sm font-mono text-pink-300 font-bold">{Math.round((scoreB / 10) * 100)}%</span>
              </div>
            </div>
            <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden mt-3 border border-slate-800">
              <div 
                className="bg-gradient-to-r from-pink-500 to-purple-500 h-full rounded-full transition-all duration-700"
                style={{ width: `${(scoreB / 10) * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* Primary Action Buttons */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3 sm:gap-4">
          {/* Review Answers Button */}
          <button
            onClick={() => {
              sound.playSelect();
              setShowReview(true);
            }}
            className="px-6 py-3.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs sm:text-sm uppercase tracking-wider flex items-center gap-2 transition-all shadow-lg shadow-purple-900/50 hover:scale-[1.02] active:scale-[0.98]"
          >
            <BookOpen className="w-4 h-4" />
            <span>REVIEW ANSWERS</span>
          </button>

          {/* View Certificate */}
          <button
            onClick={() => {
              sound.playSelect();
              setShowCert(true);
            }}
            className="px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-purple-500/40 text-purple-300 hover:text-white font-bold text-xs sm:text-sm uppercase tracking-wider flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <Award className="w-4 h-4 text-pink-400" />
            <span>EVENT CERTIFICATE</span>
          </button>

          {/* Share Scorecard */}
          <button
            onClick={handleShare}
            className="px-5 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white font-bold text-xs sm:text-sm uppercase tracking-wider flex items-center gap-2 transition-all"
            title="Copy scorecard to clipboard"
          >
            {copiedShare ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span className="text-emerald-400">COPIED!</span>
              </>
            ) : (
              <>
                <Share2 className="w-4 h-4" />
                <span>SHARE SCORE</span>
              </>
            )}
          </button>

          {/* Restart Quiz */}
          <button
            onClick={() => {
              sound.playNext();
              onRestartQuiz();
            }}
            className="px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white font-bold text-xs sm:text-sm uppercase tracking-wider flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <RotateCcw className="w-4 h-4" />
            <span>RESTART QUIZ</span>
          </button>
        </div>
      </div>

      {/* Review Modal */}
      <ReviewModal
        questions={questions}
        answers={answers}
        isOpen={showReview}
        onClose={() => setShowReview(false)}
      />

      {/* Certificate Modal */}
      <CertificateModal
        isOpen={showCert}
        onClose={() => setShowCert(false)}
        participant={participant}
        score={totalScore}
        totalMarks={maxScore}
        percentage={percentage}
        tier={tier}
      />
    </div>
  );
}
