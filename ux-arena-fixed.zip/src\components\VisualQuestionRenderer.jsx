import React from 'react';
import { 
  Search, 
  ShoppingCart, 
  Bell, 
  Settings, 
  ArrowRight, 
  ArrowLeftRight, 
  AlertTriangle, 
  Menu, 
  Star, 
  CheckCircle, 
  Lock, 
  Mail, 
  User, 
  ChevronRight,
  ExternalLink,
  Laptop,
  Smartphone,
  Eye
} from 'lucide-react';

export default function VisualQuestionRenderer({ question }) {
  if (!question) return null;

  switch (question.type) {
    // Q1: Decode the Emoji! (🎨 + 🖥️ + ✏️)
    case 'emoji-decode':
      return (
        <div className="w-full flex flex-col items-center justify-center py-6 px-4">
          <div className="flex flex-wrap items-center justify-center gap-4 md:gap-8">
            <div className="group relative flex flex-col items-center p-6 bg-slate-900/80 border border-purple-500/40 rounded-2xl shadow-glow-purple backdrop-blur-md transition-all duration-300 hover:scale-105">
              <span className="text-6xl md:text-7xl filter drop-shadow-[0_0_15px_rgba(168,85,247,0.5)]">🎨</span>
              <span className="mt-3 text-xs md:text-sm font-semibold tracking-wider text-purple-300 uppercase">Visual Arts</span>
            </div>

            <span className="text-3xl md:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400 animate-pulse">
              +
            </span>

            <div className="group relative flex flex-col items-center p-6 bg-slate-900/80 border border-blue-500/40 rounded-2xl shadow-glow-blue backdrop-blur-md transition-all duration-300 hover:scale-105">
              <span className="text-6xl md:text-7xl filter drop-shadow-[0_0_15px_rgba(59,130,246,0.5)]">🖥️</span>
              <span className="mt-3 text-xs md:text-sm font-semibold tracking-wider text-blue-300 uppercase">Digital Screen</span>
            </div>

            <span className="text-3xl md:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-cyan-400 animate-pulse">
              +
            </span>

            <div className="group relative flex flex-col items-center p-6 bg-slate-900/80 border border-pink-500/40 rounded-2xl shadow-glow-pink backdrop-blur-md transition-all duration-300 hover:scale-105">
              <span className="text-6xl md:text-7xl filter drop-shadow-[0_0_15px_rgba(236,72,153,0.5)]">✏️</span>
              <span className="mt-3 text-xs md:text-sm font-semibold tracking-wider text-pink-300 uppercase">Drafting</span>
            </div>
          </div>
          <p className="mt-5 text-sm md:text-base text-slate-400 font-mono text-center">
            Synthesis: Creativity + Digital Display + Precision Drafting
          </p>
        </div>
      );

    // Q2: Guess the Design Tool! (Figma & Canva logos)
    case 'tool-logos':
      return (
        <div className="w-full flex flex-col items-center justify-center py-4 px-2">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 w-full max-w-xl">
            {/* Figma Card */}
            <div className="flex flex-col items-center p-6 bg-slate-900/80 border border-purple-500/30 rounded-2xl shadow-lg hover:border-purple-400 transition-all group">
              <div className="w-24 h-24 flex items-center justify-center p-2 rounded-2xl bg-[#1e1e2e]/90 shadow-inner group-hover:scale-110 transition-transform duration-300">
                {/* Official Figma SVG Logo */}
                <svg className="w-16 h-16" viewBox="0 0 38 57" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M19 28.5C19 23.2533 23.2533 19 28.5 19C33.7467 19 38 23.2533 38 28.5C38 33.7467 33.7467 38 28.5 38C23.2533 38 19 33.7467 19 28.5Z" fill="#1ABCFE"/>
                  <path d="M0 47.5C0 42.2533 4.25329 38 9.5 38H19V47.5C19 52.7467 14.7467 57 9.5 57C4.25329 57 0 52.7467 0 47.5Z" fill="#0ACF83"/>
                  <path d="M19 0V19H28.5C33.7467 19 38 14.7467 38 9.5C38 4.25329 33.7467 0 28.5 0H19Z" fill="#FF7262"/>
                  <path d="M0 9.5C0 14.7467 4.25329 19 9.5 19H19V0H9.5C4.25329 0 0 4.25329 0 9.5Z" fill="#F24E1E"/>
                  <path d="M0 28.5C0 33.7467 4.25329 38 9.5 38H19V19H9.5C4.25329 19 0 23.2533 0 28.5Z" fill="#A259FF"/>
                </svg>
              </div>
              <h4 className="mt-4 text-xl font-bold text-white tracking-wide">Figma</h4>
              <span className="text-xs text-purple-300 font-mono mt-1">Design • Prototype • System</span>
            </div>

            {/* Canva Card */}
            <div className="flex flex-col items-center p-6 bg-slate-900/80 border border-cyan-500/30 rounded-2xl shadow-lg hover:border-cyan-400 transition-all group">
              <div className="w-24 h-24 flex items-center justify-center p-2 rounded-2xl bg-gradient-to-tr from-[#00C4CC] to-[#7D2AE8] shadow-inner group-hover:scale-110 transition-transform duration-300">
                {/* Official Style Canva SVG Logo */}
                <svg className="w-14 h-14" viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M100 20C55.8 20 20 55.8 20 100C20 144.2 55.8 180 100 180C144.2 180 180 144.2 180 100C180 55.8 144.2 20 100 20ZM103.5 136.2C85.1 136.2 73.4 122.9 73.4 102.7C73.4 82.3 86.8 65.5 107.1 65.5C119.5 65.5 128.2 72.1 131.7 82.5L118.2 86.8C116.1 80.3 111.4 76.5 105.8 76.5C93.8 76.5 86.3 87.8 86.3 102.2C86.3 116.3 93.3 125.4 104.6 125.4C111.6 125.4 117.4 121.2 119.9 114.7L133.2 118.9C128.8 129.5 118.4 136.2 103.5 136.2Z" fill="white"/>
                </svg>
              </div>
              <h4 className="mt-4 text-xl font-bold text-white tracking-wide">Canva</h4>
              <span className="text-xs text-cyan-300 font-mono mt-1">Template • Graphics • Social</span>
            </div>
          </div>
        </div>
      );

    // Q3: Decode the User Journey! (👤 → 📝 → 🔐 → ✅)
    case 'user-journey':
      return (
        <div className="w-full flex flex-col items-center justify-center py-6 px-2">
          <div className="w-full max-w-3xl overflow-x-auto pb-4">
            <div className="flex items-center justify-between min-w-[550px] px-4">
              {question.steps?.map((step, idx) => (
                <React.Fragment key={idx}>
                  <div className="flex flex-col items-center text-center group">
                    <div className="w-16 h-16 md:w-20 md:h-20 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 border-2 border-purple-500/40 flex items-center justify-center text-3xl md:text-4xl shadow-glow-purple group-hover:scale-110 group-hover:border-purple-400 transition-all duration-300">
                      {step.icon}
                    </div>
                    <span className="mt-3 font-semibold text-sm md:text-base text-slate-200">
                      {step.label}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">
                      {step.desc}
                    </span>
                  </div>

                  {idx < question.steps.length - 1 && (
                    <div className="flex-1 flex items-center justify-center px-2">
                      <div className="w-full h-1 bg-gradient-to-r from-purple-500/60 via-pink-500/60 to-blue-500/60 rounded-full relative">
                        <ArrowRight className="w-5 h-5 text-pink-400 absolute right-0 -top-2 animate-pulse" />
                      </div>
                    </div>
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>
          <div className="mt-3 text-xs md:text-sm text-purple-300/80 bg-purple-950/40 border border-purple-500/20 px-4 py-1.5 rounded-full">
            Visual Flow: 👤 → 📝 → 🔐 → ✅
          </div>
        </div>
      );

    // Q4: Icon Detective! (Search, Shopping Cart, Bell, Settings)
    case 'icon-detective':
      return (
        <div className="w-full flex flex-col items-center justify-center py-4 px-2">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 w-full max-w-2xl">
            <div className="flex flex-col items-center p-6 bg-slate-900/80 border border-purple-500/30 rounded-2xl shadow-lg hover:border-purple-400 hover:shadow-glow-purple transition-all group">
              <span className="text-xs font-mono font-bold text-purple-400 mb-2">OPTION A</span>
              <div className="w-16 h-16 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 group-hover:scale-110 transition-transform">
                <Search className="w-8 h-8" />
              </div>
              <span className="mt-3 text-sm font-semibold text-slate-200">Search</span>
            </div>

            <div className="flex flex-col items-center p-6 bg-slate-900/80 border border-blue-500/30 rounded-2xl shadow-lg hover:border-blue-400 hover:shadow-glow-blue transition-all group">
              <span className="text-xs font-mono font-bold text-blue-400 mb-2">OPTION B</span>
              <div className="w-16 h-16 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform">
                <ShoppingCart className="w-8 h-8" />
              </div>
              <span className="mt-3 text-sm font-semibold text-slate-200">Cart</span>
            </div>

            <div className="flex flex-col items-center p-6 bg-slate-900/80 border border-pink-500/30 rounded-2xl shadow-lg hover:border-pink-400 hover:shadow-glow-pink transition-all group">
              <span className="text-xs font-mono font-bold text-pink-400 mb-2">OPTION C</span>
              <div className="w-16 h-16 rounded-xl bg-pink-500/10 border border-pink-500/30 flex items-center justify-center text-pink-400 group-hover:scale-110 transition-transform">
                <Bell className="w-8 h-8" />
              </div>
              <span className="mt-3 text-sm font-semibold text-slate-200">Bell</span>
            </div>

            <div className="flex flex-col items-center p-6 bg-slate-900/80 border border-cyan-500/30 rounded-2xl shadow-lg hover:border-cyan-400 hover:shadow-glow-cyan transition-all group">
              <span className="text-xs font-mono font-bold text-cyan-400 mb-2">OPTION D</span>
              <div className="w-16 h-16 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 group-hover:scale-110 transition-transform">
                <Settings className="w-8 h-8" />
              </div>
              <span className="mt-3 text-sm font-semibold text-slate-200">Settings</span>
            </div>
          </div>
        </div>
      );

    // Q5: Decode the Design! (📱 ↔️ 💻)
    case 'responsive-design':
      return (
        <div className="w-full flex flex-col items-center justify-center py-6 px-4">
          <div className="flex flex-col md:flex-row items-center justify-center gap-6 md:gap-10 w-full max-w-xl">
            {/* Mobile Device Frame */}
            <div className="w-40 sm:w-48 bg-slate-900 border-2 border-purple-500/40 rounded-[28px] p-3 shadow-glow-purple flex flex-col items-center">
              <div className="w-12 h-3 bg-slate-800 rounded-full mb-2" />
              <div className="w-full h-36 bg-slate-950 rounded-xl p-2.5 flex flex-col justify-between border border-purple-500/20">
                <div className="flex justify-between items-center pb-1.5 border-b border-slate-800">
                  <div className="w-4 h-2 bg-purple-400 rounded-sm" />
                  <div className="w-2.5 h-2.5 bg-slate-700 rounded-sm" />
                </div>
                <div className="space-y-1.5">
                  <div className="w-full h-3 bg-purple-500/30 rounded-sm" />
                  <div className="w-3/4 h-2 bg-slate-800 rounded-sm" />
                  <div className="w-full h-8 bg-gradient-to-r from-purple-500/20 to-blue-500/20 rounded-md border border-purple-500/30 flex items-center justify-center">
                    <span className="text-[9px] text-purple-300 font-mono">1 Column Stack</span>
                  </div>
                </div>
                <div className="w-full h-4 bg-purple-600/40 rounded text-[8px] flex items-center justify-center text-purple-200">
                  Mobile (375px)
                </div>
              </div>
              <div className="w-8 h-1 bg-slate-700 rounded-full mt-2" />
            </div>

            {/* Glowing Arrow Indicator */}
            <div className="flex flex-col items-center justify-center py-2">
              <div className="p-3 bg-slate-900/80 border border-pink-500/40 rounded-full shadow-glow-pink">
                <ArrowLeftRight className="w-8 h-8 text-pink-400 animate-pulse" />
              </div>
              <span className="text-xs font-mono text-pink-300 mt-2 font-semibold">Fluid Reflow</span>
            </div>

            {/* Desktop Device Frame */}
            <div className="w-64 sm:w-72 bg-slate-900 border-2 border-blue-500/40 rounded-xl p-3 shadow-glow-blue flex flex-col items-center">
              <div className="w-full h-36 bg-slate-950 rounded-lg p-2.5 flex flex-col justify-between border border-blue-500/20">
                <div className="flex justify-between items-center pb-1.5 border-b border-slate-800">
                  <div className="flex items-center gap-1.5">
                    <div className="w-2 h-2 rounded-full bg-red-400/80" />
                    <div className="w-2 h-2 rounded-full bg-yellow-400/80" />
                    <div className="w-2 h-2 rounded-full bg-green-400/80" />
                  </div>
                  <div className="w-20 h-2 bg-slate-800 rounded-sm" />
                </div>
                <div className="grid grid-cols-3 gap-1.5 my-auto">
                  <div className="h-14 bg-gradient-to-b from-blue-500/20 to-purple-500/20 rounded border border-blue-500/30 p-1 flex flex-col justify-between">
                    <div className="w-full h-1.5 bg-blue-400/40 rounded-sm" />
                    <div className="w-1/2 h-1 bg-slate-700 rounded-sm" />
                    <div className="w-full h-3 bg-blue-500/30 rounded text-[7px] text-center text-blue-200">Col 1</div>
                  </div>
                  <div className="h-14 bg-gradient-to-b from-blue-500/20 to-purple-500/20 rounded border border-blue-500/30 p-1 flex flex-col justify-between">
                    <div className="w-full h-1.5 bg-blue-400/40 rounded-sm" />
                    <div className="w-1/2 h-1 bg-slate-700 rounded-sm" />
                    <div className="w-full h-3 bg-blue-500/30 rounded text-[7px] text-center text-blue-200">Col 2</div>
                  </div>
                  <div className="h-14 bg-gradient-to-b from-blue-500/20 to-purple-500/20 rounded border border-blue-500/30 p-1 flex flex-col justify-between">
                    <div className="w-full h-1.5 bg-blue-400/40 rounded-sm" />
                    <div className="w-1/2 h-1 bg-slate-700 rounded-sm" />
                    <div className="w-full h-3 bg-blue-500/30 rounded text-[7px] text-center text-blue-200">Col 3</div>
                  </div>
                </div>
                <div className="w-full h-4 bg-blue-600/40 rounded text-[8px] flex items-center justify-center text-blue-200">
                  Desktop (1440px)
                </div>
              </div>
              <div className="w-16 h-2 bg-slate-800 rounded-b mt-1" />
              <div className="w-24 h-1 bg-slate-700 rounded-full mt-0.5" />
            </div>
          </div>
        </div>
      );

    // Q6: Guess the Website! (Realistic E-commerce Mockup)
    case 'ecommerce-mockup':
      return (
        <div className="w-full flex justify-center py-2 px-1">
          <div className="w-full max-w-2xl bg-[#0f1123] border border-purple-500/30 rounded-2xl overflow-hidden shadow-2xl">
            {/* Browser top chrome */}
            <div className="bg-[#171a36] px-4 py-2 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-full bg-red-500/80" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
                <div className="w-3 h-3 rounded-full bg-green-500/80" />
                <span className="ml-3 text-xs font-mono text-slate-400 hidden sm:inline">https://aurasound.store/products/anc-headphones</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-mono text-purple-400 bg-purple-950/60 px-2 py-0.5 rounded border border-purple-500/30">
                  LIVE STORE PREVIEW
                </span>
              </div>
            </div>

            {/* E-commerce Store Header */}
            <div className="bg-[#12142d] px-4 py-2.5 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-purple-500 to-pink-500 flex items-center justify-center font-bold text-white text-xs">
                  A
                </div>
                <span className="font-bold text-sm tracking-wider text-white">AURA AUDIO</span>
              </div>
              <div className="flex items-center gap-4 text-xs text-slate-300">
                <div className="hidden sm:flex items-center gap-1.5 bg-slate-900/80 px-3 py-1 rounded-full border border-slate-700">
                  <Search className="w-3.5 h-3.5 text-slate-400" />
                  <span className="text-slate-400 text-[11px]">Search audio gear...</span>
                </div>
                <div className="relative flex items-center gap-1 bg-purple-500/20 border border-purple-500/40 px-2.5 py-1 rounded-full text-purple-300 font-semibold cursor-pointer">
                  <ShoppingCart className="w-3.5 h-3.5" />
                  <span>Cart</span>
                  <span className="ml-1 bg-pink-500 text-white rounded-full px-1.5 py-0.2 text-[10px] font-bold">2</span>
                </div>
              </div>
            </div>

            {/* Product Body */}
            <div className="p-4 sm:p-5 grid grid-cols-1 sm:grid-cols-12 gap-4 items-center">
              {/* Product Visual */}
              <div className="sm:col-span-5 bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col items-center justify-center relative group">
                <span className="absolute top-2 left-2 bg-pink-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                  -28% OFF
                </span>
                <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-gradient-to-tr from-purple-600/30 via-pink-600/20 to-blue-600/30 flex items-center justify-center my-2 shadow-inner">
                  <span className="text-5xl">🎧</span>
                </div>
                <span className="text-[11px] text-slate-400 font-mono">Spatial ANC Wireless</span>
              </div>

              {/* Product Details & Purchase Controls */}
              <div className="sm:col-span-7 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1 text-yellow-400 text-xs mb-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
                    ))}
                    <span className="text-slate-400 ml-1.5 text-[11px] font-mono">4.9 (1,420 reviews)</span>
                  </div>
                  <h3 className="text-base sm:text-lg font-bold text-white">
                    Aura Elite Pro Wireless ANC Headset
                  </h3>
                  <div className="flex items-baseline gap-2 mt-2">
                    <span className="text-xl sm:text-2xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400">
                      $249.00
                    </span>
                    <span className="text-sm text-slate-500 line-through">$349.00</span>
                    <span className="text-xs text-emerald-400 font-semibold bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                      Save $100
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1.5">
                    Premium active noise cancellation with 40-hour battery life.
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-wrap items-center gap-2.5">
                  <button className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold text-xs py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 shadow-md shadow-purple-900/30">
                    <ShoppingCart className="w-3.5 h-3.5" />
                    ADD TO CART
                  </button>
                  <button className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs py-2 px-3 rounded-lg border border-slate-700">
                    Buy Now
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      );

    // Q7: Spot the Better Design! (Side-by-side Mobile Login A vs B)
    case 'design-comparison':
      return (
        <div className="w-full flex flex-col items-center justify-center py-2 px-1">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-3xl">
            {/* DESIGN A: Bad UX */}
            <div className="flex flex-col items-center">
              <div className="w-full bg-red-950/20 border-2 border-red-500/40 rounded-2xl p-4 shadow-lg flex flex-col items-center">
                <div className="w-full flex items-center justify-between pb-2 mb-3 border-b border-red-500/30">
                  <span className="text-xs font-mono font-bold text-red-400 flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-red-500" />
                    DESIGN A
                  </span>
                  <span className="text-[10px] text-red-300 font-mono bg-red-900/40 px-2 py-0.5 rounded border border-red-500/30">
                    Poor Alignment & Cramped
                  </span>
                </div>

                {/* Mobile screen mockup for A */}
                <div className="w-full max-w-[240px] bg-[#1a0a0a] border border-red-800/50 rounded-xl p-3 flex flex-col gap-2">
                  <h4 className="text-xs font-extrabold text-yellow-300 uppercase tracking-widest text-left">
                    LOGIN TO UR ACC!
                  </h4>
                  <div className="w-full bg-[#3a1010] p-1 border border-yellow-500/40 text-[9px] text-yellow-200">
                    enter email here pls:
                  </div>
                  <div className="w-4/5 bg-[#250d0d] p-2 border border-red-400 text-[11px] text-gray-400">
                    password****
                  </div>
                  <div className="flex items-center gap-1 text-[8px] text-red-400">
                    <input type="checkbox" className="accent-red-500" defaultChecked />
                    <span>rememebr me on this machine</span>
                  </div>
                  <div className="w-16 bg-yellow-400 text-black font-extrabold text-[9px] py-0.5 px-1 rounded-none text-center self-start mt-1 cursor-not-allowed">
                    SUBMIT
                  </div>
                  <span className="text-[7px] text-red-600 underline text-right">forgot pwd? click</span>
                </div>
              </div>
            </div>

            {/* DESIGN B: Good UX */}
            <div className="flex flex-col items-center">
              <div className="w-full bg-emerald-950/20 border-2 border-emerald-500/50 rounded-2xl p-4 shadow-glow-purple flex flex-col items-center">
                <div className="w-full flex items-center justify-between pb-2 mb-3 border-b border-emerald-500/30">
                  <span className="text-xs font-mono font-bold text-emerald-400 flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                    DESIGN B
                  </span>
                  <span className="text-[10px] text-emerald-300 font-mono bg-emerald-900/40 px-2 py-0.5 rounded border border-emerald-500/30">
                    Clean, Modern & Accessible
                  </span>
                </div>

                {/* Mobile screen mockup for B */}
                <div className="w-full max-w-[240px] bg-slate-900/90 border border-purple-500/30 rounded-xl p-3.5 flex flex-col gap-2.5 shadow-md">
                  <div>
                    <h4 className="text-sm font-bold text-white">Welcome Back</h4>
                    <p className="text-[10px] text-slate-400">Please enter your credentials.</p>
                  </div>
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2 bg-slate-800/80 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-300">
                      <Mail className="w-3.5 h-3.5 text-purple-400" />
                      <span className="text-[11px] text-slate-400">designer@sparkle.org</span>
                    </div>
                    <div className="flex items-center gap-2 bg-slate-800/80 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-300">
                      <Lock className="w-3.5 h-3.5 text-purple-400" />
                      <span className="text-[11px] text-slate-400">••••••••••••</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="text-slate-400">Remember me</span>
                    <span className="text-purple-400 hover:underline cursor-pointer">Forgot password?</span>
                  </div>
                  <button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white font-bold text-xs py-1.5 rounded-lg shadow-sm">
                    Sign In
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      );

    // Q8: Identify the Navigation Pattern! (Breadcrumb: Home > Products > Mobiles)
    case 'breadcrumb-nav':
      return (
        <div className="w-full flex flex-col items-center justify-center py-6 px-4">
          <div className="w-full max-w-2xl bg-slate-900/90 border border-purple-500/30 rounded-2xl p-6 shadow-glow-purple">
            <div className="text-xs font-mono text-purple-400 mb-3 tracking-wider uppercase">
              UI Navigation Element Display:
            </div>
            
            {/* Visual Breadcrumb bar */}
            <div className="flex flex-wrap items-center gap-2 sm:gap-3 bg-slate-950/80 border border-slate-800 px-4 py-3.5 rounded-xl">
              <div className="flex items-center gap-1.5 text-purple-400 hover:text-purple-300 font-medium text-sm sm:text-base cursor-pointer">
                <span>Home</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-500" />
              <div className="flex items-center gap-1.5 text-purple-400 hover:text-purple-300 font-medium text-sm sm:text-base cursor-pointer">
                <span>Products</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-500" />
              <div className="flex items-center gap-1.5 text-white font-bold text-sm sm:text-base bg-purple-500/20 px-2.5 py-1 rounded-md border border-purple-500/40">
                <span>Mobiles</span>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400 font-mono">
              <span>Representation: Home &gt; Products &gt; Mobiles</span>
              <span className="text-purple-300">Hierarchical Location Trail</span>
            </div>
          </div>
        </div>
      );

    // Q9: Identify the UX Principle! (Confirmation Dialog)
    case 'confirmation-modal':
      return (
        <div className="w-full flex flex-col items-center justify-center py-4 px-2">
          {/* Simulated App Screen with Active Dialog Modal */}
          <div className="relative w-full max-w-md bg-slate-950 border border-slate-800 rounded-2xl p-6 shadow-2xl overflow-hidden">
            {/* Background dimmed interface */}
            <div className="filter blur-sm opacity-30 pointer-events-none space-y-3">
              <div className="w-3/4 h-4 bg-slate-700 rounded" />
              <div className="w-full h-12 bg-slate-800 rounded-lg" />
              <div className="w-full h-12 bg-slate-800 rounded-lg" />
            </div>

            {/* Centered Confirmation Dialog */}
            <div className="relative mt-2 bg-[#14162e] border-2 border-red-500/50 rounded-2xl p-5 shadow-glow-pink">
              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-red-500/20 border border-red-500/40 flex items-center justify-center shrink-0">
                  <AlertTriangle className="w-5 h-5 text-red-400" />
                </div>
                <div>
                  <h4 className="text-base font-bold text-white">Permanently Delete File?</h4>
                  <p className="mt-1 text-xs text-slate-300 leading-relaxed">
                    "Are you sure you want to permanently delete this file?"
                  </p>
                  <p className="mt-1 text-[11px] text-red-300 font-mono">
                    ⚠️ This action cannot be undone.
                  </p>
                </div>
              </div>

              <div className="mt-5 flex items-center justify-end gap-2.5 pt-3 border-t border-slate-800">
                <button className="px-3.5 py-1.5 text-xs font-semibold text-slate-300 bg-slate-800/80 hover:bg-slate-700 rounded-lg border border-slate-700">
                  Cancel
                </button>
                <button className="px-3.5 py-1.5 text-xs font-bold text-white bg-red-600 hover:bg-red-500 rounded-lg shadow-md shadow-red-900/30">
                  Delete File
                </button>
              </div>
            </div>
          </div>
        </div>
      );

    // Q10: Match the Icon! (Hamburger Menu)
    case 'hamburger-menu':
      return (
        <div className="w-full flex flex-col items-center justify-center py-4 px-2">
          <div className="w-full max-w-xl bg-slate-900/90 border border-purple-500/30 rounded-2xl p-5 shadow-glow-purple">
            <div className="text-xs font-mono text-purple-400 mb-3 tracking-wider uppercase">
              Web Header Navigation Showcase:
            </div>

            {/* Header simulation with focused Hamburger Menu icon */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 flex items-center justify-between">
              {/* Highlighted Hamburger Icon */}
              <div className="relative group">
                <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl blur opacity-75 group-hover:opacity-100 transition duration-300 animate-pulse" />
                <div className="relative p-2.5 bg-slate-900 border-2 border-purple-400 rounded-xl flex flex-col gap-1.5 cursor-pointer shadow-lg">
                  <div className="w-7 h-1 bg-white rounded-full" />
                  <div className="w-7 h-1 bg-white rounded-full" />
                  <div className="w-7 h-1 bg-white rounded-full" />
                </div>
              </div>

              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-md bg-purple-600 flex items-center justify-center text-xs font-bold text-white">
                  ✦
                </div>
                <span className="font-bold text-sm text-slate-200">SPARKLE PORTAL</span>
              </div>

              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs text-slate-400">
                  <User className="w-4 h-4" />
                </div>
              </div>
            </div>

            <div className="mt-4 flex items-center justify-center gap-2">
              <span className="text-xs font-mono text-purple-300 bg-purple-950/60 px-3 py-1 rounded-full border border-purple-500/30">
                Icon Highlight: 3 Parallel Horizontal Lines
              </span>
            </div>
          </div>
        </div>
      );

    default:
      return null;
  }
}
