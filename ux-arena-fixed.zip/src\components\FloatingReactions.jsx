import React, { useState, useEffect } from 'react';
import { realtimeSync } from '../lib/realtimeSync';

export default function FloatingReactions() {
  const [reactions, setReactions] = useState([]);

  useEffect(() => {
    const unsubscribe = realtimeSync.subscribeReactions((reaction) => {
      setReactions((prev) => [...prev, reaction]);

      // Remove after 3.5 seconds
      setTimeout(() => {
        setReactions((prev) => prev.filter((r) => r.id !== reaction.id));
      }, 3500);
    });

    return () => unsubscribe();
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
      {reactions.map((r) => (
        <div
          key={r.id}
          className="absolute bottom-6 text-3xl sm:text-4xl filter drop-shadow-[0_0_12px_rgba(236,72,153,0.7)] animate-float-up"
          style={{
            left: `${r.x}%`,
            animation: 'floatUp 3.2s cubic-bezier(0.2, 0.8, 0.2, 1) forwards'
          }}
        >
          {r.emoji}
        </div>
      ))}
    </div>
  );
}
