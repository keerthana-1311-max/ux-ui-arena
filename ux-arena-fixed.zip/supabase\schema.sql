-- ==============================================================================
-- SPARKLE '26 – UX ARENA LIVE QUIZ PLATFORM
-- PRODUCTION SUPABASE DATABASE SCHEMA, RLS POLICIES & RPC FUNCTIONS
-- ==============================================================================

-- 1. Enable pgcrypto extension for UUID generation
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ==============================================================================
-- 2. QUIZ SESSIONS TABLE
-- Tracks the live authoritative state of the quiz arena
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.quiz_sessions (
    id TEXT PRIMARY KEY DEFAULT 'active',
    pin TEXT NOT NULL DEFAULT 'UX2026',
    status TEXT NOT NULL DEFAULT 'registration' 
        CHECK (status IN ('registration', 'in_progress', 'completed', 'finalized')),
    registration_open BOOLEAN NOT NULL DEFAULT true,
    current_question_index INTEGER NOT NULL DEFAULT -1,
    question_started_at TIMESTAMPTZ,
    question_duration INTEGER NOT NULL DEFAULT 20,
    is_locked BOOLEAN NOT NULL DEFAULT false,
    is_paused BOOLEAN NOT NULL DEFAULT false,
    time_remaining INTEGER NOT NULL DEFAULT 20,
    results_published BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Ensure the single active session exists
INSERT INTO public.quiz_sessions (id, pin, status, registration_open, current_question_index, question_duration)
VALUES ('active', 'UX2026', 'registration', true, -1, 20)
ON CONFLICT (id) DO NOTHING;

-- ==============================================================================
-- 3. PARTICIPANTS TABLE
-- Stores contender profiles joining the live session
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.quiz_participants (
    id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL DEFAULT 'active' REFERENCES public.quiz_sessions(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    team_name TEXT NOT NULL,
    joined_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Index for fast lookup by session
CREATE INDEX IF NOT EXISTS idx_participants_session ON public.quiz_participants(session_id);

-- ==============================================================================
-- 4. QUIZ QUESTIONS & PROTECTED ANSWER BANK
-- Stores the official 10 questions with answer keys protected from participant view
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.quiz_questions (
    id INTEGER PRIMARY KEY,
    section TEXT NOT NULL,
    section_title TEXT NOT NULL,
    marks INTEGER NOT NULL DEFAULT 1,
    type TEXT NOT NULL,
    question TEXT NOT NULL,
    options JSONB NOT NULL,
    steps JSONB,
    correct_answer TEXT NOT NULL,
    explanation TEXT
);

-- Insert the authoritative 10 questions with official answers
INSERT INTO public.quiz_questions (id, section, section_title, marks, type, question, options, steps, correct_answer, explanation)
VALUES
(
    1, 'A', 'Section A – Decode the Design', 1, 'emoji-decode',
    'Decode the emoji: 🎨 + 🖥️ + ✏️ — which field does this combination describe?',
    '[{"id":"A","text":"UI/UX Design"},{"id":"B","text":"Print Publishing"},{"id":"C","text":"Video Editing"},{"id":"D","text":"Game Development"}]'::jsonb,
    NULL,
    'A',
    'Visual art (🎨), a digital screen (🖥️) and precise drafting (✏️) together describe UI/UX design: crafting visual, screen-based experiences with deliberate structure.'
),
(
    2, 'A', 'Section A – Decode the Design', 1, 'tool-logos',
    'Which two design tools are shown?',
    '[{"id":"A","text":"Sketch and Photoshop"},{"id":"B","text":"Figma and Canva"},{"id":"C","text":"XD and Illustrator"},{"id":"D","text":"Framer and Penpot"}]'::jsonb,
    NULL,
    'B',
    'The multicolour five-circle mark is Figma (collaborative interface design); the gradient script mark is Canva (template-driven graphics).'
),
(
    3, 'A', 'Section A – Decode the Design', 1, 'user-journey',
    'What user journey does this flow represent?',
    '[{"id":"A","text":"Checkout funnel"},{"id":"B","text":"Onboarding and authentication flow"},{"id":"C","text":"Bug-reporting flow"},{"id":"D","text":"Content publishing flow"}]'::jsonb,
    '[{"icon":"👤","label":"User","desc":"Arrives"},{"icon":"📝","label":"Sign Up","desc":"Creates account"},{"icon":"🔐","label":"Login","desc":"Authenticates"},{"icon":"✅","label":"Success","desc":"Reaches goal"}]'::jsonb,
    'B',
    'Visitor → sign up → log in → success is an onboarding and authentication journey. Mapping such flows exposes friction points.'
),
(
    4, 'A', 'Section A – Decode the Design', 1, 'icon-detective',
    'Which icon is the universal symbol for notifications?',
    '[{"id":"A","text":"Magnifying glass"},{"id":"B","text":"Shopping cart"},{"id":"C","text":"Bell"},{"id":"D","text":"Gear"}]'::jsonb,
    NULL,
    'C',
    'The bell is the established notification metaphor. Following conventions supports "Consistency and standards" (Nielsen heuristic).'
),
(
    5, 'A', 'Section A – Decode the Design', 1, 'responsive-design',
    'A layout reflows from 3 columns (desktop) to 1 stacked column (mobile). What is this called?',
    '[{"id":"A","text":"Adaptive caching"},{"id":"B","text":"Responsive design"},{"id":"C","text":"Skeuomorphism"},{"id":"D","text":"Progressive disclosure"}]'::jsonb,
    NULL,
    'B',
    'Responsive design uses fluid grids and breakpoints so content reflows to fit any screen size.'
),
(
    6, 'B', 'Section B – Visual UI/UX Challenge', 2, 'ecommerce-mockup',
    'Which element on this product page builds buyer trust through social proof?',
    '[{"id":"A","text":"Star rating with review count"},{"id":"B","text":"The search bar"},{"id":"C","text":"The browser URL"},{"id":"D","text":"The cart icon"}]'::jsonb,
    NULL,
    'A',
    'Ratings with review counts (4.9 from 1,420 reviews) are social proof, a proven e-commerce pattern that reduces purchase uncertainty.'
),
(
    7, 'B', 'Section B – Visual UI/UX Challenge', 2, 'design-comparison',
    'Compare Design A and Design B. Which login screen has better usability?',
    '[{"id":"A","text":"Design A: compact and minimal"},{"id":"B","text":"Design B: clear labels, spacing and hierarchy"},{"id":"C","text":"Both are equal"},{"id":"D","text":"Neither, a login should use a modal"}]'::jsonb,
    NULL,
    'B',
    'Design B has clear labels, readable text, correct spelling and visible hierarchy. Design A has typos, cramped targets and unclear affordances, violating "Aesthetic and minimalist design" and "Recognition rather than recall".'
),
(
    8, 'B', 'Section B – Visual UI/UX Challenge', 2, 'breadcrumb-nav',
    'Home > Products > Mobiles is which navigation pattern?',
    '[{"id":"A","text":"Tab bar"},{"id":"B","text":"Pagination"},{"id":"C","text":"Breadcrumb navigation"},{"id":"D","text":"Mega menu"}]'::jsonb,
    NULL,
    'C',
    'Breadcrumbs show the hierarchical location trail, supporting "Visibility of system status" and easy backtracking.'
),
(
    9, 'B', 'Section B – Visual UI/UX Challenge', 2, 'confirmation-modal',
    'A dialog asks "Permanently Delete File?" before deleting. Which usability heuristic is this?',
    '[{"id":"A","text":"Aesthetic design"},{"id":"B","text":"Flexibility and efficiency"},{"id":"C","text":"Error prevention"},{"id":"D","text":"Help and documentation"}]'::jsonb,
    NULL,
    'C',
    'Confirming destructive actions is Error Prevention: it stops costly mistakes before they happen.'
),
(
    10, 'B', 'Section B – Visual UI/UX Challenge', 2, 'hamburger-menu',
    'What does the highlighted three-line icon in the header represent?',
    '[{"id":"A","text":"Settings panel"},{"id":"B","text":"Download"},{"id":"C","text":"Navigation menu (hamburger)"},{"id":"D","text":"Text alignment"}]'::jsonb,
    NULL,
    'C',
    'The hamburger icon collapses primary navigation into a menu, saving space on small screens.'
)
ON CONFLICT (id) DO UPDATE SET
    section = EXCLUDED.section,
    section_title = EXCLUDED.section_title,
    marks = EXCLUDED.marks,
    type = EXCLUDED.type,
    question = EXCLUDED.question,
    options = EXCLUDED.options,
    steps = EXCLUDED.steps,
    correct_answer = EXCLUDED.correct_answer,
    explanation = EXCLUDED.explanation;

-- ==============================================================================
-- 5. QUIZ ANSWERS TABLE
-- Records participant submissions with unique constraint to prevent duplicates
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.quiz_answers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id TEXT NOT NULL DEFAULT 'active' REFERENCES public.quiz_sessions(id) ON DELETE CASCADE,
    participant_id TEXT NOT NULL REFERENCES public.quiz_participants(id) ON DELETE CASCADE,
    question_id INTEGER NOT NULL REFERENCES public.quiz_questions(id) ON DELETE CASCADE,
    selected_option TEXT NOT NULL CHECK (selected_option IN ('A', 'B', 'C', 'D')),
    submitted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT unique_participant_question UNIQUE (session_id, participant_id, question_id)
);

CREATE INDEX IF NOT EXISTS idx_answers_session_question ON public.quiz_answers(session_id, question_id);
CREATE INDEX IF NOT EXISTS idx_answers_participant ON public.quiz_answers(participant_id);

-- ==============================================================================
-- 6. QUIZ RESULTS TABLE
-- Stores official ranked scoreboard calculated server-side
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.quiz_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id TEXT NOT NULL DEFAULT 'active' REFERENCES public.quiz_sessions(id) ON DELETE CASCADE,
    participant_id TEXT NOT NULL REFERENCES public.quiz_participants(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    team_name TEXT NOT NULL,
    rank INTEGER NOT NULL,
    total_score INTEGER NOT NULL,
    section_a_score INTEGER NOT NULL,
    section_b_score INTEGER NOT NULL,
    correct_count INTEGER NOT NULL,
    incorrect_count INTEGER NOT NULL,
    unanswered_count INTEGER NOT NULL,
    answers_breakdown JSONB,
    published_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT unique_session_participant_result UNIQUE (session_id, participant_id)
);

CREATE INDEX IF NOT EXISTS idx_results_session ON public.quiz_results(session_id);

-- ==============================================================================
-- 7. ROW LEVEL SECURITY (RLS) POLICIES
-- Clean, reliable policies for live arena event operations (supporting anon & authenticated)
-- ==============================================================================

ALTER TABLE public.quiz_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quiz_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quiz_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quiz_answers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quiz_results ENABLE ROW LEVEL SECURITY;

-- Drop previous policies if they exist to allow clean re-runs
DROP POLICY IF EXISTS "Public can view active session" ON public.quiz_sessions;
DROP POLICY IF EXISTS "Authenticated coordinators can manage session" ON public.quiz_sessions;
DROP POLICY IF EXISTS "Public can manage session" ON public.quiz_sessions;

DROP POLICY IF EXISTS "Public can view participants" ON public.quiz_participants;
DROP POLICY IF EXISTS "Public can register as participant" ON public.quiz_participants;
DROP POLICY IF EXISTS "Coordinators can delete participants" ON public.quiz_participants;
DROP POLICY IF EXISTS "Public can manage participants" ON public.quiz_participants;

DROP POLICY IF EXISTS "Coordinators can view questions and answers" ON public.quiz_questions;
DROP POLICY IF EXISTS "Public can view questions" ON public.quiz_questions;

DROP POLICY IF EXISTS "Coordinators can view all answers" ON public.quiz_answers;
DROP POLICY IF EXISTS "Participants can view own answers" ON public.quiz_answers;
DROP POLICY IF EXISTS "Participants can insert answer" ON public.quiz_answers;
DROP POLICY IF EXISTS "Public can view all answers" ON public.quiz_answers;
DROP POLICY IF EXISTS "Public can submit answers" ON public.quiz_answers;

DROP POLICY IF EXISTS "Coordinators can view results" ON public.quiz_results;
DROP POLICY IF EXISTS "Coordinators can manage results" ON public.quiz_results;
DROP POLICY IF EXISTS "Participants can view results only after publication" ON public.quiz_results;
DROP POLICY IF EXISTS "Public can view and manage results" ON public.quiz_results;

-- --- QUIZ SESSIONS POLICIES ---
-- Allows both coordinator dashboard (anon or auth) and participants to read/update session state
CREATE POLICY "Public can manage session" 
    ON public.quiz_sessions FOR ALL 
    TO anon, authenticated 
    USING (true) 
    WITH CHECK (true);

-- --- QUIZ PARTICIPANTS POLICIES ---
-- Allows participant check-in, presence queries, and coordinator removals
CREATE POLICY "Public can manage participants" 
    ON public.quiz_participants FOR ALL 
    TO anon, authenticated 
    USING (true) 
    WITH CHECK (true);

-- --- QUIZ QUESTIONS POLICIES ---
CREATE POLICY "Public can view questions" 
    ON public.quiz_questions FOR SELECT 
    TO anon, authenticated 
    USING (true);

-- Public view omitting confidential answer keys:
CREATE OR REPLACE VIEW public.public_quiz_questions AS
SELECT id, section, section_title, marks, type, question, options, steps
FROM public.quiz_questions;

-- --- QUIZ ANSWERS POLICIES ---
-- Allows coordinator live answer review and participant submissions
CREATE POLICY "Public can view all answers" 
    ON public.quiz_answers FOR SELECT 
    TO anon, authenticated 
    USING (true);

CREATE POLICY "Public can submit answers" 
    ON public.quiz_answers FOR ALL 
    TO anon, authenticated 
    USING (true) 
    WITH CHECK (true);

-- --- QUIZ RESULTS POLICIES ---
CREATE POLICY "Public can view and manage results" 
    ON public.quiz_results FOR ALL 
    TO anon, authenticated 
    USING (true) 
    WITH CHECK (true);

-- ==============================================================================
-- 8. SECURE DATABASE FUNCTIONS (RPC)
-- Server-authoritative logic for answers submission & result publication
-- ==============================================================================

-- A. Submit Answer RPC (UPSERT: supports selecting and switching choices seamlessly)
CREATE OR REPLACE FUNCTION public.submit_answer(
    p_participant_id TEXT,
    p_question_id INTEGER,
    p_selected_option TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_session public.quiz_sessions%ROWTYPE;
BEGIN
    -- 1. Fetch current active session
    SELECT * INTO v_session FROM public.quiz_sessions WHERE id = 'active';
    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'error', 'No active session found');
    END IF;

    -- 2. Validate session status
    IF v_session.status <> 'in_progress' THEN
        RETURN jsonb_build_object('success', false, 'error', 'Quiz is not currently active');
    END IF;

    -- 3. Validate lock & pause
    IF v_session.is_locked THEN
        RETURN jsonb_build_object('success', false, 'error', 'Question is locked by coordinator');
    END IF;

    IF v_session.is_paused THEN
        RETURN jsonb_build_object('success', false, 'error', 'Quiz is currently paused by coordinator');
    END IF;

    -- 4. Upsert answer: allows participant to freely change choice anytime before timer expires
    INSERT INTO public.quiz_answers (session_id, participant_id, question_id, selected_option, submitted_at)
    VALUES ('active', p_participant_id, p_question_id, p_selected_option, now())
    ON CONFLICT (session_id, participant_id, question_id) 
    DO UPDATE SET 
        selected_option = EXCLUDED.selected_option, 
        submitted_at = now();

    RETURN jsonb_build_object('success', true, 'selected_option', p_selected_option);
END;
$$;

-- B. Calculate and Publish Results RPC
-- Server-side score evaluation with answer keys protected inside PostgreSQL
CREATE OR REPLACE FUNCTION public.publish_quiz_results()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_part RECORD;
    v_q RECORD;
    v_ans RECORD;
    v_total INTEGER;
    v_sec_a INTEGER;
    v_sec_b INTEGER;
    v_correct INTEGER;
    v_incorrect INTEGER;
    v_unanswered INTEGER;
    v_breakdown JSONB;
    v_count INTEGER := 0;
BEGIN
    -- Delete previous results for fresh calculation
    DELETE FROM public.quiz_results WHERE session_id = 'active';

    -- Loop over every registered participant
    FOR v_part IN SELECT id, name, team_name FROM public.quiz_participants WHERE session_id = 'active' LOOP
        v_total := 0;
        v_sec_a := 0;
        v_sec_b := 0;
        v_correct := 0;
        v_incorrect := 0;
        v_unanswered := 0;
        v_breakdown := '{}'::jsonb;

        -- Loop over all 10 questions in order
        FOR v_q IN SELECT id, section, marks, correct_answer FROM public.quiz_questions ORDER BY id ASC LOOP
            -- Look up participant's submission
            SELECT selected_option INTO v_ans 
            FROM public.quiz_answers 
            WHERE session_id = 'active' AND participant_id = v_part.id AND question_id = v_q.id;

            IF NOT FOUND OR v_ans.selected_option IS NULL THEN
                v_unanswered := v_unanswered + 1;
                v_breakdown := v_breakdown || jsonb_build_object(v_q.id::text, jsonb_build_object(
                    'status', 'unanswered',
                    'selected', NULL,
                    'selectedOption', NULL,
                    'correctAnswer', v_q.correct_answer,
                    'marks', 0
                ));
            ELSIF v_ans.selected_option = v_q.correct_answer THEN
                v_correct := v_correct + 1;
                IF v_q.section = 'A' THEN
                    v_sec_a := v_sec_a + v_q.marks;
                ELSE
                    v_sec_b := v_sec_b + v_q.marks;
                END IF;
                v_total := v_total + v_q.marks;
                v_breakdown := v_breakdown || jsonb_build_object(v_q.id::text, jsonb_build_object(
                    'status', 'correct',
                    'selected', v_ans.selected_option,
                    'selectedOption', v_ans.selected_option,
                    'correctAnswer', v_q.correct_answer,
                    'marks', v_q.marks
                ));
            ELSE
                v_incorrect := v_incorrect + 1;
                v_breakdown := v_breakdown || jsonb_build_object(v_q.id::text, jsonb_build_object(
                    'status', 'incorrect',
                    'selected', v_ans.selected_option,
                    'selectedOption', v_ans.selected_option,
                    'correctAnswer', v_q.correct_answer,
                    'marks', 0
                ));
            END IF;
        END LOOP;

        -- Insert intermediate results row (rank updated in next step)
        INSERT INTO public.quiz_results (
            session_id, participant_id, name, team_name, rank,
            total_score, section_a_score, section_b_score,
            correct_count, incorrect_count, unanswered_count,
            answers_breakdown
        )
        VALUES (
            'active', v_part.id, v_part.name, v_part.team_name, 0,
            v_total, v_sec_a, v_sec_b,
            v_correct, v_incorrect, v_unanswered,
            v_breakdown
        );
        v_count := v_count + 1;
    END LOOP;

    -- Calculate competitive rankings (standard competition ranking / tie handling)
    WITH ranked AS (
        SELECT id, DENSE_RANK() OVER (ORDER BY total_score DESC, correct_count DESC, id ASC) AS computed_rank
        FROM public.quiz_results
        WHERE session_id = 'active'
    )
    UPDATE public.quiz_results r
    SET rank = ranked.computed_rank
    FROM ranked
    WHERE r.id = ranked.id;

    -- Update session to published and finalized
    UPDATE public.quiz_sessions 
    SET results_published = true, status = 'finalized', updated_at = now()
    WHERE id = 'active';

    RETURN jsonb_build_object('success', true, 'total_participants', v_count);
END;
$$;

-- C. Reset Quiz Session RPC
CREATE OR REPLACE FUNCTION public.reset_quiz_session()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    DELETE FROM public.quiz_answers WHERE session_id = 'active';
    DELETE FROM public.quiz_participants WHERE session_id = 'active';
    DELETE FROM public.quiz_results WHERE session_id = 'active';

    UPDATE public.quiz_sessions
    SET status = 'registration',
        registration_open = true,
        current_question_index = -1,
        question_started_at = NULL,
        is_locked = false,
        is_paused = false,
        time_remaining = question_duration,
        results_published = false,
        updated_at = now()
    WHERE id = 'active';

    RETURN jsonb_build_object('success', true);
END;
$$;

-- ==============================================================================
-- 9. SUPABASE REALTIME REPLICATION ENABLEMENT
-- Ensure all connected clients receive instant push updates without refresh
-- ==============================================================================

-- Ensure Full Replica Identity so updates and deletes carry full payload
ALTER TABLE public.quiz_sessions REPLICA IDENTITY FULL;
ALTER TABLE public.quiz_participants REPLICA IDENTITY FULL;
ALTER TABLE public.quiz_answers REPLICA IDENTITY FULL;
ALTER TABLE public.quiz_results REPLICA IDENTITY FULL;

-- Add tables to realtime publication
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_publication_tables 
        WHERE pubname = 'supabase_realtime' AND tablename = 'quiz_sessions'
    ) THEN
        ALTER PUBLICATION supabase_realtime ADD TABLE public.quiz_sessions;
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_publication_tables 
        WHERE pubname = 'supabase_realtime' AND tablename = 'quiz_participants'
    ) THEN
        ALTER PUBLICATION supabase_realtime ADD TABLE public.quiz_participants;
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_publication_tables 
        WHERE pubname = 'supabase_realtime' AND tablename = 'quiz_answers'
    ) THEN
        ALTER PUBLICATION supabase_realtime ADD TABLE public.quiz_answers;
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_publication_tables 
        WHERE pubname = 'supabase_realtime' AND tablename = 'quiz_results'
    ) THEN
        ALTER PUBLICATION supabase_realtime ADD TABLE public.quiz_results;
    END IF;
END;
$$;
