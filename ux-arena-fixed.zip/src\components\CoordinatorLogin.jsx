import React, { useState } from 'react';
import { ShieldCheck, Lock, Mail, Key, ArrowRight, AlertCircle, Info, UserPlus, LogIn } from 'lucide-react';
import { supabase, isSupabaseConfigured } from '../lib/supabase';

export default function CoordinatorLogin({ onLoginSuccess, onCancel }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [isSignUpMode, setIsSignUpMode] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setMessage('');
    setLoading(true);

    const formattedEmail = email.includes('@') ? email.trim() : `${email.trim().toLowerCase()}@sparkle2026.com`;

    if (isSupabaseConfigured() && supabase) {
      try {
        if (isSignUpMode) {
          const { data, error: signUpErr } = await supabase.auth.signUp({
            email: formattedEmail,
            password: password,
          });
          if (signUpErr) throw signUpErr;

          if (data.session) {
            onLoginSuccess();
          } else {
            setMessage('Coordinator account registered! If email confirmation is enabled on your Supabase project, please confirm or check Supabase Auth dashboard.');
          }
        } else {
          const { data, error: signInErr } = await supabase.auth.signInWithPassword({
            email: formattedEmail,
            password: password,
          });
          if (signInErr) throw signInErr;

          if (data?.session) {
            onLoginSuccess();
          } else {
            throw new Error('No active session returned from Supabase Auth.');
          }
        }
      } catch (err) {
        console.error('Coordinator auth error:', err);
        setError(err.message || 'Authentication failed. Please verify coordinator credentials.');
      } finally {
        setLoading(false);
      }
    } else {
      // Offline / Unconfigured fallback
      setTimeout(() => {
        if (password.length >= 6) {
          sessionStorage.setItem('sparkle_coordinator_auth', 'authenticated_' + Date.now());
          onLoginSuccess();
        } else {
          setError('Supabase is not configured in .env. For local development demo, passkey must be at least 6 characters.');
        }
        setLoading(false);
      }, 400);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl animate-fadeIn">
      <div className="w-full max-w-md glass-panel p-6 sm:p-8 rounded-3xl border-2 border-purple-500/40 shadow-glow-purple relative overflow-hidden">
        {/* Glow background accent */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-purple-600/15 rounded-full blur-3xl pointer-events-none" />

        {/* Header */}
        <div className="flex flex-col items-center text-center mb-6">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-purple-600 to-pink-600 flex items-center justify-center text-white shadow-lg mb-3">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <span className="text-[11px] font-mono tracking-widest text-purple-400 uppercase font-bold bg-purple-950/80 px-3 py-0.5 rounded-full border border-purple-500/30">
            RESTRICTED ACCESS
          </span>
          <h2 className="text-2xl font-extrabold text-white font-display mt-2">
            Coordinator Portal
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            SPARKLE '26 – Supabase Authorized Operations
          </p>
        </div>

        {!isSupabaseConfigured() && (
          <div className="mb-4 p-3 bg-amber-950/50 border border-amber-500/30 rounded-xl text-xs text-amber-200 flex items-start gap-2">
            <Info className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
            <span>
              <strong>Note:</strong> Supabase keys not detected in .env. Running in local development mode. Add <code className="text-white">VITE_SUPABASE_URL</code> to enable real Supabase Auth.
            </span>
          </div>
        )}

        {error && (
          <div className="mb-4 p-3 bg-red-950/60 border border-red-500/40 rounded-xl text-xs text-red-300 flex items-start gap-2 animate-pulse">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-400" />
            <span>{error}</span>
          </div>
        )}

        {message && (
          <div className="mb-4 p-3 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-xs text-emerald-300 flex items-start gap-2">
            <Info className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
            <span>{message}</span>
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-mono text-slate-300 mb-1 flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-purple-400" />
              <span>Coordinator Email / Username:</span>
            </label>
            <input
              type="text"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="coordinator@sparkle2026.com"
              className="w-full bg-slate-900/90 border border-purple-500/40 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400 transition"
            />
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-300 mb-1 flex items-center gap-1.5">
              <Key className="w-3.5 h-3.5 text-pink-400" />
              <span>Coordinator Password:</span>
            </label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••••••"
              className="w-full bg-slate-900/90 border border-purple-500/40 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400 transition"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-2 py-3.5 rounded-xl font-display font-bold text-sm tracking-wider uppercase text-white shadow-lg shadow-purple-900/50 hover:shadow-glow-purple transition-all duration-300 flex items-center justify-center gap-2 group cursor-pointer disabled:opacity-50"
            style={{
              background: 'linear-gradient(135deg, #8b5cf6 0%, #ec4899 100%)'
            }}
          >
            {loading ? (
              <span>Authenticating...</span>
            ) : isSignUpMode ? (
              <>
                <UserPlus className="w-4 h-4" />
                <span>Create Coordinator Account</span>
              </>
            ) : (
              <>
                <LogIn className="w-4 h-4" />
                <span>Sign In via Supabase Auth</span>
              </>
            )}
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </form>

        {isSupabaseConfigured() && (
          <div className="mt-4 text-center">
            <button
              type="button"
              onClick={() => {
                setIsSignUpMode(!isSignUpMode);
                setError('');
                setMessage('');
              }}
              className="text-xs font-mono text-purple-300 hover:text-white underline cursor-pointer"
            >
              {isSignUpMode
                ? 'Already have an account? Sign In'
                : 'Need to create the initial coordinator account? Sign Up'}
            </button>
          </div>
        )}

        <div className="mt-5 pt-4 border-t border-purple-500/20 flex items-center justify-between text-xs font-mono text-slate-400">
          <span>Supabase Auth & RLS Protected</span>
          {onCancel && (
            <button
              onClick={onCancel}
              className="text-purple-300 hover:text-white hover:underline cursor-pointer"
            >
              Back to Arena
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
