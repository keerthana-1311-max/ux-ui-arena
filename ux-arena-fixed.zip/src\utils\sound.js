let ctx = null, enabled = true, lastWarn = 0;
const tone = (freq, dur = 0.12, type = 'sine', gain = 0.06, delay = 0) => {
  if (!enabled || typeof window === 'undefined') return;
  try {
    ctx = ctx || new (window.AudioContext || window.webkitAudioContext)();
    const t = ctx.currentTime + delay, osc = ctx.createOscillator(), g = ctx.createGain();
    osc.type = type; osc.frequency.value = freq;
    g.gain.setValueAtTime(gain, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(g); g.connect(ctx.destination); osc.start(t); osc.stop(t + dur);
  } catch (e) { /* audio unavailable */ }
};
export const sound = {
  setEnabled: (v) => { enabled = !!v; },
  playSelect: () => tone(660, 0.09, 'triangle'),
  playNext: () => tone(440, 0.08, 'sine'),
  playWarning: () => { const n = Date.now(); if (n - lastWarn > 900) { lastWarn = n; tone(880, 0.1, 'square', 0.04); } },
  playVictory: () => [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.25, 'triangle', 0.07, i * 0.12)),
};
